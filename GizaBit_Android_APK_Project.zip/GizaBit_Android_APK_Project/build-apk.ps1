$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$GradleVersion = '8.13'
$GradleRoot = Join-Path $ProjectRoot ".build-tools\gradle-$GradleVersion"
$GradleZip = Join-Path $ProjectRoot ".build-tools\gradle-$GradleVersion-bin.zip"

Write-Host 'GizaBit Android APK builder' -ForegroundColor Cyan
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Locate Android Studio's bundled JDK if JAVA_HOME is not configured.
if (-not $env:JAVA_HOME) {
    $studioJbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
    if (Test-Path (Join-Path $studioJbr 'bin\java.exe')) { $env:JAVA_HOME = $studioJbr }
}
if (-not $env:JAVA_HOME -or -not (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
    throw 'Install Android Studio first, then set JAVA_HOME to its jbr folder (or install JDK 17+).'
}

# Locate the Android SDK.
if (-not $env:ANDROID_HOME -and -not $env:ANDROID_SDK_ROOT) {
    $defaultSdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
    if (Test-Path $defaultSdk) { $env:ANDROID_HOME = $defaultSdk }
}
if (-not $env:ANDROID_HOME -and $env:ANDROID_SDK_ROOT) { $env:ANDROID_HOME = $env:ANDROID_SDK_ROOT }
if (-not $env:ANDROID_HOME -or -not (Test-Path $env:ANDROID_HOME)) {
    throw 'Android SDK not found. In Android Studio > SDK Manager install Android SDK Platform 35, Build Tools 35.0.0, NDK 28.0.13004108 and CMake 3.22.1.'
}
$env:ANDROID_SDK_ROOT = $env:ANDROID_HOME

$requiredNdk = Join-Path $env:ANDROID_HOME 'ndk\28.0.13004108'
$requiredCmake = Join-Path $env:ANDROID_HOME 'cmake\3.22.1'
if (-not (Test-Path $requiredNdk)) { throw 'NDK 28.0.13004108 is missing. Install it from Android Studio > SDK Manager > SDK Tools.' }
if (-not (Test-Path $requiredCmake)) { throw 'CMake 3.22.1 is missing. Install it from Android Studio > SDK Manager > SDK Tools.' }

# Use a known Gradle version compatible with Android Gradle Plugin 8.13.2.
$gradleExe = Join-Path $GradleRoot 'bin\gradle.bat'
if (-not (Test-Path $gradleExe)) {
    New-Item -ItemType Directory -Force -Path (Split-Path $GradleRoot -Parent) | Out-Null
    Write-Host "Downloading Gradle $GradleVersion..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing -Uri "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $GradleZip
    Expand-Archive -Path $GradleZip -DestinationPath (Split-Path $GradleRoot -Parent) -Force
}

# Fetch the Node.js Mobile native runtime and headers required by the Android app.
& (Join-Path $ProjectRoot 'scripts\prepare-node-mobile.ps1')

Write-Host 'Building installable debug APK...' -ForegroundColor Cyan
Push-Location $ProjectRoot
try {
    & $gradleExe --no-daemon --stacktrace assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle failed with exit code $LASTEXITCODE" }
} finally {
    Pop-Location
}

$apk = Join-Path $ProjectRoot 'app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $apk)) { throw 'APK build finished without producing app-debug.apk.' }
$finalApk = Join-Path $ProjectRoot 'GizaBit-Android-Offline.apk'
Copy-Item $apk $finalApk -Force
Write-Host ''
Write-Host 'SUCCESS: APK generated and debug-signed.' -ForegroundColor Green
Write-Host $finalApk -ForegroundColor Green
Write-Host 'Copy this APK to the host Android phone and install it. No internet is required while using GizaBit.'
