$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$AppRoot = Join-Path $ProjectRoot 'app'
$JniRoot = Join-Path $AppRoot 'src\main\jniLibs'
$HeaderRoot = Join-Path $AppRoot 'src\main\cpp\node-mobile\include'
$DownloadRoot = Join-Path $ProjectRoot '.build-tools\node-mobile'
$ReleaseTag = 'v18.20.4'

Write-Host 'Preparing the embedded Node.js Mobile runtime...' -ForegroundColor Cyan
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
New-Item -ItemType Directory -Force -Path $DownloadRoot, $JniRoot, $HeaderRoot | Out-Null

$api = "https://api.github.com/repos/nodejs-mobile/nodejs-mobile/releases/tags/$ReleaseTag"
$headers = @{ 'User-Agent' = 'GizaBit-Android-Builder' }
$release = Invoke-RestMethod -Uri $api -Headers $headers
$asset = $release.assets | Where-Object {
    $_.name -match '(?i)android' -and $_.name -match '(?i)(\.zip|\.tar\.gz)$'
} | Select-Object -First 1

if (-not $asset) {
    throw "Could not find an Android archive in Node.js Mobile release $ReleaseTag. Open https://github.com/nodejs-mobile/nodejs-mobile/releases and check the Android assets."
}

$archive = Join-Path $DownloadRoot $asset.name
if (-not (Test-Path $archive)) {
    Write-Host "Downloading $($asset.name)..."
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $archive
}

$extract = Join-Path $DownloadRoot 'extracted'
if (Test-Path $extract) { Remove-Item $extract -Recurse -Force }
New-Item -ItemType Directory -Force -Path $extract | Out-Null
if ($asset.name -match '(?i)\.zip$') {
    Expand-Archive -Path $archive -DestinationPath $extract -Force
} else {
    tar -xf $archive -C $extract
}

$foundLibraries = Get-ChildItem -Path $extract -Recurse -File -Filter 'libnode.so'
$copied = @()
foreach ($lib in $foundLibraries) {
    $abi = $lib.Directory.Name
    if ($abi -in @('arm64-v8a', 'armeabi-v7a', 'x86_64')) {
        $destination = Join-Path (Join-Path $JniRoot $abi) 'libnode.so'
        New-Item -ItemType Directory -Force -Path (Split-Path $destination -Parent) | Out-Null
        Copy-Item $lib.FullName $destination -Force
        $copied += $abi
    }
}

$nodeHeader = Get-ChildItem -Path $extract -Recurse -File -Filter 'node.h' | Select-Object -First 1
if (-not $nodeHeader) { throw 'Node.js Mobile archive did not contain node.h.' }
$includeDir = $nodeHeader.Directory.Parent.FullName
if ((Split-Path $includeDir -Leaf) -ne 'include') {
    throw "Unexpected Node.js headers path: $($nodeHeader.FullName)"
}
if (Test-Path $HeaderRoot) { Remove-Item $HeaderRoot -Recurse -Force }
Copy-Item $includeDir $HeaderRoot -Recurse -Force

if ('arm64-v8a' -notin $copied) { throw 'The arm64-v8a libnode.so library is required for modern Android phones.' }
Write-Host "Node.js Mobile runtime prepared for: $($copied -join ', ')" -ForegroundColor Green
Write-Host 'This is a build-time download only. The installed GizaBit APK runs the bundled files locally.' -ForegroundColor Green
