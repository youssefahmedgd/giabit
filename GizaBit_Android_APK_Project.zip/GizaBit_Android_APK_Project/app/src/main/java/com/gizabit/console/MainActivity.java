package com.gizabit.console;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final String LOCAL_URL = "http://127.0.0.1:3000/";
    private static final String HEALTH_URL = "http://127.0.0.1:3000/api/health";
    private static final AtomicBoolean NODE_START_REQUESTED = new AtomicBoolean(false);
    private static final int IMMERSIVE_FLAGS =
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;

    static {
        System.loadLibrary("node");
        System.loadLibrary("native-lib");
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private WebView webView;
    private TextView statusText;
    private ProgressBar progressBar;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private int healthAttempts = 0;
    private boolean pageOpened = false;

    public native int startNodeWithArguments(String[] arguments);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        applyImmersiveMode();
        buildStartupUi();
        configureWebView();
        prepareAndStartNode();
        waitForLocalServer();
    }

    private void buildStartupUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 12, 23));

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(dp(28), dp(28), dp(28), dp(28));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.gizabit.console.R.drawable.gizabit_icon);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(116), dp(116));
        logoParams.bottomMargin = dp(20);
        panel.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText("GizaBit");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        panel.addView(title);

        statusText = new TextView(this);
        statusText.setText("Preparing your offline game console...");
        statusText.setTextColor(Color.LTGRAY);
        statusText.setTextSize(14);
        statusText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statusParams.topMargin = dp(14);
        panel.addView(statusText, statusParams);

        progressBar = new ProgressBar(this);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(180), dp(4));
        progressParams.topMargin = dp(22);
        panel.addView(progressBar, progressParams);

        root.addView(panel, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void configureWebView() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8, 12, 23));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                // The host APK stays inside its local copy of GizaBit.
                return host != null && !(host.equals("127.0.0.1") || host.equals("localhost"));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                root.addView(customView, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT));
                webView.setVisibility(View.GONE);
                applyImmersiveMode();
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                webView.setVisibility(View.VISIBLE);
                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                    customViewCallback = null;
                }
                applyImmersiveMode();
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        webView.setVisibility(View.GONE);
    }

    private void prepareAndStartNode() {
        if (!NODE_START_REQUESTED.compareAndSet(false, true)) return;

        new Thread(() -> {
            File nodeProject = new File(getFilesDir(), "gizabit-nodejs-project");
            try {
                if (wasApkUpdated() || !new File(nodeProject, "server.js").isFile()) {
                    deleteRecursively(nodeProject);
                    if (!copyAssetFolder(getAssets(), "nodejs-project", nodeProject.getAbsolutePath())) {
                        throw new IOException("Could not copy GizaBit game files from the APK.");
                    }
                    saveApkUpdateTime();
                }

                File serverFile = new File(nodeProject, "server.js");
                if (!serverFile.isFile()) throw new IOException("GizaBit server.js is missing.");

                runOnUiThread(() -> statusText.setText("Starting the local GizaBit server..."));
                startNodeWithArguments(new String[]{"node", serverFile.getAbsolutePath()});
                runOnUiThread(() -> showFatalError("The GizaBit server stopped unexpectedly. Close and reopen the app."));
            } catch (Exception error) {
                NODE_START_REQUESTED.set(false);
                runOnUiThread(() -> showFatalError("GizaBit could not start: " + error.getMessage()));
            }
        }, "GizaBit-Node-Runtime").start();
    }

    private void waitForLocalServer() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (pageOpened || isFinishing()) return;
                healthAttempts++;
                if (isServerReady()) {
                    pageOpened = true;
                    progressBar.setVisibility(View.GONE);
                    statusText.setText("GizaBit is ready. Loading your console...");
                    webView.setVisibility(View.VISIBLE);
                    webView.loadUrl(LOCAL_URL);
                    return;
                }
                if (healthAttempts >= 120) {
                    showFatalError("The local server did not respond. Restart the app and try again.");
                    return;
                }
                handler.postDelayed(this, 500);
            }
        }, 500);
    }

    private boolean isServerReady() {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(HEALTH_URL).openConnection();
            connection.setConnectTimeout(350);
            connection.setReadTimeout(350);
            connection.setUseCaches(false);
            return connection.getResponseCode() == 200;
        } catch (Exception ignored) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void showFatalError(String message) {
        if (statusText != null) statusText.setText(message);
        if (progressBar != null) progressBar.setVisibility(View.GONE);
    }

    private void applyImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE_FLAGS);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            root.removeView(customView);
            customView = null;
            webView.setVisibility(View.VISIBLE);
            if (customViewCallback != null) {
                customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }
            applyImmersiveMode();
            return;
        }
        if (webView != null && webView.getVisibility() == View.VISIBLE && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Stop hosting GizaBit?")
                .setMessage("Leaving the app will stop the local server and disconnect players.")
                .setNegativeButton("Keep playing", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("Exit", (dialog, which) -> {
                    finishAndRemoveTask();
                    Process.killProcess(Process.myPid());
                })
                .show();
    }

    private boolean wasApkUpdated() {
        long previous = getPreferences(Context.MODE_PRIVATE).getLong("apk_last_update", 0L);
        long current = getPackageUpdateTime();
        return previous != current;
    }

    private void saveApkUpdateTime() {
        getPreferences(Context.MODE_PRIVATE).edit().putLong("apk_last_update", getPackageUpdateTime()).apply();
    }

    private long getPackageUpdateTime() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                return getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime;
            }
            return getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime;
        } catch (Exception ignored) {
            return 1L;
        }
    }

    private static boolean copyAssetFolder(AssetManager manager, String source, String destination) {
        try {
            String[] children = manager.list(source);
            if (children != null && children.length > 0) {
                File targetDirectory = new File(destination);
                if (!targetDirectory.exists() && !targetDirectory.mkdirs()) return false;
                for (String child : children) {
                    if (!copyAssetFolder(manager, source + "/" + child,
                            destination + File.separator + child)) return false;
                }
                return true;
            }

            File targetFile = new File(destination);
            File parent = targetFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) return false;
            try (InputStream input = manager.open(source);
                 OutputStream output = new FileOutputStream(targetFile)) {
                copyStream(input, output);
                return true;
            } catch (IOException notAFile) {
                // Empty directories are harmless; create them and continue.
                return targetFile.mkdirs() || targetFile.isDirectory();
            }
        } catch (Exception error) {
            return false;
        }
    }

    private static void copyStream(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[16 * 1024];
        int read;
        while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
        output.flush();
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) deleteRecursively(child);
        }
        //noinspection ResultOfMethodCallIgnored
        file.delete();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
