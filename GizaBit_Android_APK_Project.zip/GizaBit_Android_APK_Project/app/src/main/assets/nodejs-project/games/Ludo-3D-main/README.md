# 🎲 LUDO 3D

> A **fully interactive 3D Ludo board game** built with Three.js in a single HTML file for the Nairaland Coding Challenge.

![Ludo 3D Banner](https://img.shields.io/badge/Three.js-3D%20Game-blue?style=for-the-badge&logo=three.js)
![HTML5](https://img.shields.io/badge/HTML5-Single%20File-orange?style=for-the-badge&logo=html5)
![Status](https://img.shields.io/badge/Status-Complete-success?style=for-the-badge)

---

## ✨ Features

### 🎮 Game Modes
- **Pass & Play** – Local multiplayer for 2 or 4 players on the same device
- **Vs Computer** – Challenge AI opponents (1v1 or 1v3 bots)

### 🎨 Visual Excellence
- **Fully 3D rendered board** using Three.js with realistic lighting and shadows
- **Smooth token animations** with step-by-step movement and hop effects
- **Dynamic camera controls** – Rotate, zoom, and explore the board from any angle
- **Glowing base indicators** to show the current player's turn
- **Vibrant confetti celebration** on victory
- **Modern glassmorphism UI** with gradient backgrounds
- **Fully responsive design** – Works on desktop, tablet, and mobile devices

### 🔊 Audio Experience
- **Procedural sound effects** generated using the Web Audio API:
  - Dice roll sounds
  - Token hop sounds for each step
  - Capture sound effects
  - Safe zone chimes
  - Home entry fanfare
  - Victory celebration music
- **Background music** with toggle control

### 🎯 Gameplay Features
- **Smart AI** with strategic decision-making (prioritizes captures, safe zones, and home entry)
- **Color selection** – Choose your preferred token color before starting
- **Interactive dice** – Click the 3D dice or button to roll
- **Token highlighting** – Valid moves are clearly indicated with glowing rings
- **Capture mechanics** – Send opponents back to their home base
- **Safe zones** – Star cells and starting positions protect your tokens
- **Extra turn on 6** – Roll a 6 to get another turn
- **Win detection** – Game ends when a player gets all 4 tokens home

### 🛠️ Board Controls
- 🔒 **Lock/Unlock rotation** – Prevent accidental board rotation
- 🔍 **Zoom in/out** – Get closer or see the full board
- ⛶ **Fullscreen mode** – Immersive gaming experience  
- 🎵 **Music toggle** – Enable/disable background music

---

## 📜 Game Rules

1. **Objective:** Move all 4 of your tokens from the base to the center home triangle
2. **Starting:** Roll a 6 to move a token from your base onto the starting cell
3. **Movement:** Move your tokens clockwise around the board equal to the dice value
4. **Rolling 6:** When you roll a 6, you get an extra turn after moving
5. **Capture:** Land on an opponent's token to send it back to their base
6. **Safe Zones:** Tokens on star cells or colored starting cells cannot be captured
7. **Home Entry:** Enter the final path leading to home after completing the track
8. **Winning:** The first player to get all 4 tokens home wins the game!

---

## 🖼️ Screenshots

### Main Menu
![Main Menu Screenshot](https://i.ibb.co/BVN21Qg6/Screenshot-2025-12-18-063526.png)

### 3D Game Board
![Main Menu Screenshot](https://i.ibb.co/6706ZdRT/Screenshot-2025-12-18-065425.png)

### Color Selection
![Main Menu Screenshot](https://i.ibb.co/FL9Tdjkx/Screenshot-2025-12-18-065754.png)

### Victory Screen
![Main Menu Screenshot](https://i.ibb.co/WWjrZkvY/Screenshot-2025-12-18-072125.png)

---

## 🛠️ Technology Stack

| Technology | Purpose |
|------------|---------|
| **HTML5** | Single-file structure |
| **CSS3** | Responsive styling, animations, glassmorphism effects |
| **JavaScript (ES6+)** | Game logic, state management |
| **Three.js** | 3D rendering, camera controls, lighting |
| **Web Audio API** | Procedural sound generation |
| **Font Awesome** | UI icons |
| **Google Fonts (Poppins)** | Typography |

---

## 🚀 Getting Started

### Quick Start
Simply open `ludo-game.html` in any modern web browser!

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/Ludo-main.git

# Navigate to the directory
cd Ludo-main

# Open in browser (or just double-click the file)
open ludo-game.html
```

### Requirements
- Any modern web browser (Chrome, Firefox, Safari, Edge)
- JavaScript enabled
- No installation or dependencies required – everything runs in-browser!

---

## 💻 Development Information

### IDE
**Google Antigravity**

### AI Model
**Claude Opus 4.5 (Thinking)**

### File Structure
```
Ludo-main/
├── README.md         # This file
└──  index.html    # Complete game in a single file (~3000 lines)
```

### Code Architecture
The game is organized into logical sections within the HTML file:

1. **CSS Styles** (Lines 11-1328)
   - CSS variables for consistent theming
   - Responsive media queries for all screen sizes
   - Animations and transitions

2. **HTML Structure** (Lines 1330-1519)
   - Menu overlay
   - Color selection modal
   - Game container with 3D canvas
   - Control panel with dice and scoreboard
   - Rules and win modals

3. **JavaScript Game Engine** (Lines 1530-3053)
   - Three.js scene initialization
   - Board construction with cells, bases, and paths
   - Token creation and movement
   - Game logic (turns, captures, win detection)
   - AI decision-making
   - Sound system
   - UI updates

---

## 🎯 Feature Highlights

### Intelligent AI
The computer opponent uses a scoring system to make strategic decisions:
- **+100 points** for entering home
- **+50 points** for capturing an opponent
- **+10 points** for landing on safe zones
- **+5 points** for leaving the base
- Position advancement is also factored in

### Responsive Design
The game adapts seamlessly to different screen sizes:
- **Desktop** (>1024px): Side-by-side board and control panel
- **Tablet** (768-1024px): Optimized controls and board size
- **Mobile** (<768px): Stacked layout with compact UI
- **Small Mobile** (<480px): Touch-friendly with adjusted spacing

### Performance Optimized
- GPU-accelerated 3D rendering
- Efficient animation loops
- Memory-conscious particle systems
- Lazy audio context initialization

---

## 🏆 Challenge Submission

This project was created for the **Nairaland 3D Ludo Game Challenge**.

**Prize Pool:**
- 🥇 1st Place: ₦250,000
- 🥈 2nd Place: ₦125,000

**Deadline:** December 18, 2025, 10:00 AM (WAT)

---

## 📄 License

This project was created for the Nairaland Coding Challenge and is available for educational purposes.

---

## 👨‍💻 Author

**Horladoyin**

Built with 💙 using Google Antigravity IDE and Claude Opus 4.5 (Thinking)

---

<div align="center">

**🎲 Roll the dice and enjoy the game! 🎲**

</div>
