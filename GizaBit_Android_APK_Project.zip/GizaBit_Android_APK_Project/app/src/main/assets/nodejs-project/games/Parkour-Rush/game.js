import * as THREE from 'three';

const $ = (id) => document.getElementById(id);
const canvasHost = $('game-canvas');
const isMobileRender = window.matchMedia('(pointer: coarse)').matches;
const menuScreen = $('menu-screen');
const pauseScreen = $('pause-screen');
const winScreen = $('win-screen');
const settingsScreen = $('settings-screen');
const topHud = $('top-hud');
const bottomHud = $('bottom-hud');
const toastEl = $('toast');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x91ccef);
scene.fog = new THREE.Fog(0x91ccef, 48, 165);

const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 260);
camera.position.set(0, 5.5, 9);

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobileRender ? 1.45 : 1.8));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.domElement.tabIndex = 0;
canvasHost.appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xe9f8ff, 0x3b5572, 2.0);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xfff0d2, 3.1);
sun.position.set(-18, 30, 18);
sun.castShadow = true;
sun.shadow.mapSize.set(isMobileRender ? 1024 : 2048, isMobileRender ? 1024 : 2048);
sun.shadow.camera.left = -42;
sun.shadow.camera.right = 42;
sun.shadow.camera.top = 48;
sun.shadow.camera.bottom = -130;
sun.shadow.bias = -0.0003;
scene.add(sun);

const worldFloor = new THREE.Mesh(
  new THREE.PlaneGeometry(450, 450),
  new THREE.MeshStandardMaterial({ color: 0x152d4b, roughness: 0.72, metalness: 0.08 })
);
worldFloor.rotation.x = -Math.PI / 2;
worldFloor.position.set(0, -15, -54);
worldFloor.receiveShadow = true;
scene.add(worldFloor);

const mats = {
  dark: new THREE.MeshStandardMaterial({ color: 0x182d48, roughness: 0.7, metalness: 0.15 }),
  white: new THREE.MeshStandardMaterial({ color: 0xf3fbff, roughness: 0.38 }),
  mint: new THREE.MeshStandardMaterial({ color: 0x55e5cb, emissive: 0x0c5d56, emissiveIntensity: 0.55, roughness: 0.32 }),
  gold: new THREE.MeshStandardMaterial({ color: 0xffd06d, emissive: 0x885018, emissiveIntensity: 0.35, metalness: 0.55, roughness: 0.28 }),
  danger: new THREE.MeshStandardMaterial({ color: 0xff5266, emissive: 0x9d102e, emissiveIntensity: 1.2, roughness: 0.25 }),
  skyBase: new THREE.MeshStandardMaterial({ color: 0x345b79, roughness: 0.82 }),
  neoBase: new THREE.MeshStandardMaterial({ color: 0x28244e, roughness: 0.68, metalness: 0.18 }),
  lavaBase: new THREE.MeshStandardMaterial({ color: 0x653b35, roughness: 0.78 })
};

function makeSurfaceTexture(kind, base, accent) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 512;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 512, 512);
  let seed = kind.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0) + 97;
  const rand = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
  if (kind === 'grass') {
    for (let i = 0; i < 1900; i++) {
      const x = rand() * 512, y = rand() * 512;
      ctx.strokeStyle = i % 3 ? 'rgba(240,255,225,.13)' : 'rgba(4,68,61,.18)';
      ctx.lineWidth = 1 + rand() * 2;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (rand() - .5) * 8, y - 2 - rand() * 8); ctx.stroke();
    }
    for (let i = 0; i < 38; i++) {
      ctx.fillStyle = 'rgba(255,255,255,.035)'; ctx.beginPath();
      ctx.ellipse(rand() * 512, rand() * 512, 8 + rand() * 26, 5 + rand() * 16, rand() * 3, 0, Math.PI * 2); ctx.fill();
    }
  } else if (kind === 'lava') {
    for (let i = 0; i < 85; i++) {
      const x = rand() * 512, y = rand() * 512;
      ctx.strokeStyle = i % 2 ? 'rgba(255,174,82,.46)' : 'rgba(255,82,45,.36)';
      ctx.lineWidth = 2 + rand() * 5; ctx.shadowColor = '#ff713f'; ctx.shadowBlur = 7;
      ctx.beginPath(); ctx.moveTo(x, y);
      let px = x, py = y;
      for (let j = 0; j < 4; j++) { px += (rand() - .5) * 56; py += (rand() - .5) * 56; ctx.lineTo(px, py); }
      ctx.stroke(); ctx.shadowBlur = 0;
    }
    for (let i = 0; i < 650; i++) { ctx.fillStyle = `rgba(255,${90 + Math.floor(rand()*100)},40,${.08 + rand()*.16})`; ctx.fillRect(rand()*512, rand()*512, 1+rand()*4, 1+rand()*4); }
  } else {
    for (let i = 0; i < 170; i++) {
      const x = rand() * 512, y = rand() * 512;
      ctx.fillStyle = i % 2 ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.1)';
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 10 + rand()*40, y - 4 + rand()*15); ctx.lineTo(x + 25 + rand()*45, y + 15 + rand()*25); ctx.lineTo(x - 3, y + 20 + rand()*25); ctx.closePath(); ctx.fill();
    }
    for (let i = 0; i < 1800; i++) { ctx.fillStyle = i % 2 ? 'rgba(255,255,255,.045)' : 'rgba(0,0,0,.07)'; ctx.fillRect(rand()*512, rand()*512, 1+rand()*2, 1+rand()*2); }
    if (kind === 'neon') {
      ctx.strokeStyle = 'rgba(117,244,235,.16)'; ctx.lineWidth = 2;
      for (let i=0;i<8;i++){ctx.beginPath();ctx.moveTo(i*70,0);ctx.lineTo(i*70,512);ctx.stroke();}
    }
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(2, 2);
  texture.anisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);
  return texture;
}

const surfaceTextures = [
  makeSurfaceTexture('grass', '#397f72', '#b2f0ca'),
  makeSurfaceTexture('neon', '#32314f', '#67e8de'),
  makeSurfaceTexture('lava', '#633b34', '#ff9a50')
];
const rockTexture = makeSurfaceTexture('stone', '#405a70', '#a9c3ce');
mats.skyBase.map = rockTexture; mats.skyBase.needsUpdate = true;
mats.neoBase.map = surfaceTextures[1]; mats.neoBase.needsUpdate = true;
mats.lavaBase.map = surfaceTextures[2]; mats.lavaBase.needsUpdate = true;

const palettes = [
  { top: 0x5ee0cc, edge: 0x174f68, glow: 0x1a9f9a, base: mats.skyBase },
  { top: 0x9d8bff, edge: 0x392e76, glow: 0x7b5dff, base: mats.neoBase },
  { top: 0xffa45f, edge: 0x71352c, glow: 0xff5b42, base: mats.lavaBase }
];

const platforms = [];
const coins = [];
const hazards = [];
const remotePlayers = new Map();
const keyState = Object.create(null);
let socket = null;
let myId = null;
let roomName = 'GIZABIT';
let playerName = 'Runner';
let isRoomHost = false;
let hasJoinedRoom = false;
let roomStatus = 'disconnected';
let roomPlayers = [];
let roomHostId = null;
let raceResults = [];
let raceStartAt = 0;
let raceStartPerf = 0;
let startTimer = null;
let gameStarted = false;
let paused = false;
let won = false;
let pendingJoin = false;
let localCoinCount = 0;
let startedAt = 0;
let currentStage = 1;
let toastTimer = 0;
let elapsed = 0;
let lastNetworkSend = 0;
let cameraYaw = 0;
let cameraPitch = 0.34;
let cameraDistance = 8.0;
let cameraSensitivity = 1.0;
let isPointerLocked = false;
let settingsOpen = false;
let controlMode = 'arrows';
let joystickInput = { x: 0, y: 0 };
let joystickPointerId = null;
const cameraPointers = new Map();
let previousPinchDistance = null;
let previousSinglePointer = null;

const player = {
  pos: new THREE.Vector3(0, 0, 1.8),
  vel: new THREE.Vector3(),
  onGround: false,
  facing: 0,
  checkpoint: new THREE.Vector3(0, 0, 1.8),
  avatar: null,
  phase: 0,
  moving: false,
  standingPlatform: null
};

function makeStandard(color, roughness = 0.55, metalness = 0.05, emissive = 0x000000, emissiveIntensity = 0) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness, emissive, emissiveIntensity });
}

function addCloud(x, y, z, scale = 1) {
  const group = new THREE.Group();
  const cloudMat = new THREE.MeshStandardMaterial({ color: 0xf4fbff, roughness: 1, transparent: true, opacity: 0.86 });
  for (let i = 0; i < 5; i++) {
    const size = (0.85 + (i % 3) * 0.22) * scale;
    const puff = new THREE.Mesh(new THREE.SphereGeometry(size, 12, 9), cloudMat);
    puff.position.set((i - 2) * 0.9 * scale, Math.sin(i * 2.1) * 0.26 * scale, Math.cos(i * 1.8) * 0.22 * scale);
    group.add(puff);
  }
  group.position.set(x, y, z);
  scene.add(group);
}

function addFloatingRock(x, y, z, size, color = 0x49677d) {
  const rock = new THREE.Mesh(
    new THREE.DodecahedronGeometry(size, 0),
    makeStandard(color, 0.92)
  );
  rock.position.set(x, y, z);
  rock.rotation.set(Math.random() * 0.6, Math.random() * 2, Math.random() * 0.5);
  rock.scale.set(1.25, 0.72, 1.0);
  rock.castShadow = true;
  scene.add(rock);
}

// Distant scenery gives the course depth without requiring external 3D assets.
for (let i = 0; i < 12; i++) {
  addCloud(-27 + (i % 4) * 18, 12 + (i % 3) * 4, -14 - Math.floor(i / 4) * 34, 1.5 + (i % 2) * 0.35);
}
for (let i = 0; i < 23; i++) {
  const z = 5 - i * 5.6;
  addFloatingRock(-12 - Math.random() * 9, -1 - Math.random() * 6, z, 1.6 + Math.random() * 2.5, i % 3 === 0 ? 0x6b708f : 0x45647a);
  addFloatingRock(12 + Math.random() * 9, -1 - Math.random() * 6, z - 2, 1.5 + Math.random() * 2.7, i % 4 === 0 ? 0x786181 : 0x47627b);
}

function addPlatform(x, top, z, width, depth, zone, options = {}) {
  const palette = palettes[zone];
  const group = new THREE.Group();
  group.position.set(x, top, z);

  const base = new THREE.Mesh(new THREE.BoxGeometry(width, 0.5, depth), palette.base);
  base.position.y = -0.25;
  base.castShadow = true;
  base.receiveShadow = true;
  group.add(base);

  const capMaterial = new THREE.MeshStandardMaterial({
    color: palette.top, map: surfaceTextures[zone], roughness: zone === 2 ? 0.48 : 0.62,
    metalness: zone === 1 ? 0.28 : 0.08, emissive: palette.glow, emissiveIntensity: 0.13
  });
  const cap = new THREE.Mesh(
    new THREE.BoxGeometry(width + 0.03, 0.07, depth + 0.03), capMaterial
  );
  cap.position.y = 0.015;
  cap.castShadow = true;
  cap.receiveShadow = true;
  group.add(cap);

  const edgeMat = makeStandard(palette.edge, 0.42, 0.22, palette.glow, 0.22);
  const edgeH = 0.12;
  const edges = [
    [0, 0.06, -depth / 2 + 0.05, width, edgeH, 0.1],
    [0, 0.06, depth / 2 - 0.05, width, edgeH, 0.1],
    [-width / 2 + 0.05, 0.06, 0, 0.1, edgeH, depth],
    [width / 2 - 0.05, 0.06, 0, 0.1, edgeH, depth]
  ];
  for (const [ex, ey, ez, ew, eh, ed] of edges) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(ew, eh, ed), edgeMat);
    strip.position.set(ex, ey, ez);
    group.add(strip);
  }

  // Faceted floating-island underside, with a textured rock finish.
  const island = new THREE.Mesh(
    new THREE.ConeGeometry(Math.max(1.05, Math.min(width, depth) * 0.43), 1.65, 7, 1),
    new THREE.MeshStandardMaterial({ color: zone === 2 ? 0x613d3d : zone === 1 ? 0x34375a : 0x41677a, map: rockTexture, roughness: 0.96 })
  );
  island.rotation.x = Math.PI;
  island.rotation.y = 0.24;
  island.position.set(0, -1.02, 0);
  island.castShadow = true;
  group.add(island);
  for (let rockIndex = 0; rockIndex < 3; rockIndex++) {
    const shard = new THREE.Mesh(new THREE.DodecahedronGeometry(0.25 + rockIndex * 0.06, 0), new THREE.MeshStandardMaterial({ color: zone === 2 ? 0x87483c : 0x526c7c, map: rockTexture, roughness: 1 }));
    shard.position.set((rockIndex - 1) * width * 0.24, -0.7 - (rockIndex % 2) * 0.35, (rockIndex % 2 ? 1 : -1) * depth * 0.23);
    shard.rotation.set(rockIndex * .5, rockIndex * .7, .3);
    shard.scale.set(1.2, .8, .9);
    group.add(shard);
  }

  // Fine edge inlays and corner lights help judge safe landing space.
  const inlayMat = new THREE.MeshStandardMaterial({ color: 0xe8fffb, emissive: palette.glow, emissiveIntensity: 0.5, roughness: 0.3 });
  const inlay = new THREE.Mesh(new THREE.BoxGeometry(Math.max(0.7, width - 0.72), 0.018, 0.035), inlayMat);
  inlay.position.set(0, 0.06, -depth / 2 + 0.29);
  group.add(inlay);

  // Small corner lights make every landing pad readable in motion.
  const lightMat = makeStandard(0xdffefa, 0.25, 0.1, palette.glow, 0.65);
  for (const sx of [-1, 1]) {
    const dot = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.08, 0.13), lightMat);
    dot.position.set(sx * (width / 2 - 0.23), 0.12, -depth / 2 + 0.23);
    group.add(dot);
  }

  scene.add(group);
  const platform = {
    group, width, depth, baseX: x, top: top + 0.05, baseTop: top + 0.05,
    moving: Boolean(options.moving), moveDistance: options.moveDistance || 0,
    moveSpeed: options.moveSpeed || 1, moveOffset: options.moveOffset || 0,
    previousX: x, previousZ: z, deltaX: 0, deltaZ: 0,
    crumble: Boolean(options.crumble), crumbleStarted: null, active: true,
    checkpoint: Boolean(options.checkpoint), finish: Boolean(options.finish), index: options.index || 0,
    activated: false
  };
  platforms.push(platform);
  return platform;
}

function addCoin(x, y, z) {
  const group = new THREE.Group();
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.29, 0.095, 9, 22), mats.gold);
  ring.rotation.y = Math.PI * 0.16;
  group.add(ring);
  const center = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), makeStandard(0xfff1b6, 0.22, 0.2, 0xc88716, 0.5));
  group.add(center);
  group.position.set(x, y, z);
  scene.add(group);
  coins.push({ group, baseY: y, collected: false });
}

function addCheckpoint(platform) {
  const pole = new THREE.Group();
  const beam = new THREE.Mesh(
    new THREE.CylinderGeometry(0.045, 0.07, 2.1, 8),
    makeStandard(0xb6fff2, 0.22, 0.4, 0x30dfc5, 1.4)
  );
  beam.position.y = 1.08;
  pole.add(beam);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.075, 8, 24), mats.mint);
  ring.position.y = 1.85;
  pole.add(ring);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.66, 0.16, 12), makeStandard(0x143d50, 0.3, 0.25, 0x1dbba5, 0.55));
  base.position.y = 0.1;
  pole.add(base);
  pole.position.set(platform.group.position.x, platform.top, platform.group.position.z - platform.depth * 0.12);
  scene.add(pole);
  platform.marker = pole;
}

function addSpinner(platform, length = 5.1) {
  const pivot = new THREE.Group();
  pivot.position.set(platform.group.position.x, platform.top + 0.77, platform.group.position.z);
  const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.34, 12), mats.dark);
  axle.rotation.x = Math.PI / 2;
  pivot.add(axle);
  const beam = new THREE.Mesh(
    new THREE.BoxGeometry(length, 0.2, 0.34),
    makeStandard(0x202b42, 0.28, 0.42, 0x111c33, 0.3)
  );
  beam.castShadow = true;
  pivot.add(beam);
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(length * 0.9, 0.045, 0.365), mats.danger);
  stripe.position.y = 0.125;
  pivot.add(stripe);
  const topLine = new THREE.Mesh(new THREE.BoxGeometry(length * 0.72, 0.025, 0.37), mats.gold);
  topLine.position.y = 0.16;
  pivot.add(topLine);
  const centerHub = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.42, 16), mats.gold);
  centerHub.rotation.x = Math.PI / 2;
  pivot.add(centerHub);
  for (const side of [-1, 1]) {
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), mats.gold);
    tip.position.x = side * length * 0.48;
    pivot.add(tip);
  }
  scene.add(pivot);
  hazards.push({ group: pivot, length, angle: 0, speed: 1.15 + hazards.length * 0.12, platform });
}

function addFinishGate(platform) {
  const gate = new THREE.Group();
  const ring = new THREE.Mesh(new THREE.TorusGeometry(2.15, 0.18, 12, 48), makeStandard(0xfdf8de, 0.2, 0.35, 0xffad40, 1.2));
  gate.add(ring);
  const inner = new THREE.Mesh(new THREE.TorusGeometry(1.82, 0.055, 8, 48), mats.mint);
  inner.position.z = -0.06;
  gate.add(inner);
  const postMat = makeStandard(0x283b60, 0.3, 0.32, 0x3a9ca4, 0.5);
  for (const side of [-1, 1]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.23, 3.2, 10), postMat);
    post.position.set(side * 2.0, -0.7, 0);
    gate.add(post);
  }
  gate.position.set(platform.group.position.x, platform.top + 1.9, platform.group.position.z - 1.5);
  scene.add(gate);
  platform.gate = gate;
}

// Three themed sections: Sky Islands, Neon District, and Ember Run.
const course = [
  { x: 0, y: 0, z: 0, w: 12, d: 10, zone: 0 },
  { x: 0, y: 0, z: -8, w: 4.7, d: 4.5, zone: 0 },
  { x: 3, y: 0.35, z: -14, w: 3.5, d: 3.5, zone: 0 },
  { x: 0, y: 0.7, z: -20, w: 3.4, d: 3.4, zone: 0 },
  { x: -3, y: 1.05, z: -26, w: 3.7, d: 3.5, zone: 0, moving: true, moveDistance: 0.85, moveSpeed: 1.1 },
  { x: -3, y: 1.05, z: -32, w: 5.6, d: 4.2, zone: 0 },
  { x: 1, y: 1.4, z: -38, w: 3.5, d: 3.5, zone: 0 },
  { x: 4, y: 1.75, z: -44, w: 3.5, d: 3.5, zone: 0 },
  { x: 1, y: 2.1, z: -50, w: 5.5, d: 4.5, zone: 1, checkpoint: true },
  { x: -3, y: 2.45, z: -56, w: 3.5, d: 3.5, zone: 1 },
  { x: -4, y: 2.45, z: -62, w: 3.5, d: 3.5, zone: 1 },
  { x: 0, y: 2.9, z: -68, w: 5.6, d: 4.2, zone: 1 },
  { x: 3.7, y: 3.25, z: -74, w: 3.7, d: 3.5, zone: 1, moving: true, moveDistance: 0.95, moveSpeed: 1.25, moveOffset: 1.6 },
  { x: 3.7, y: 3.6, z: -80, w: 3.6, d: 3.5, zone: 1 },
  { x: 0, y: 3.95, z: -86, w: 5.5, d: 4.5, zone: 2, checkpoint: true },
  { x: -3.5, y: 4.3, z: -92, w: 3.6, d: 3.5, zone: 2 },
  { x: 0, y: 4.65, z: -98, w: 3.5, d: 3.5, zone: 2, crumble: true },
  { x: 3.5, y: 5.0, z: -104, w: 5.7, d: 4.3, zone: 2 },
  { x: 0, y: 5.35, z: -111, w: 10, d: 8, zone: 2, finish: true }
];

course.forEach((p, index) => {
  const platform = addPlatform(p.x, p.y, p.z, p.w, p.d, p.zone, { ...p, index });
  if (p.checkpoint) addCheckpoint(platform);
  if (p.finish) addFinishGate(platform);
  if (p.crumble) {
    const warning = new THREE.Mesh(new THREE.TorusGeometry(0.64, 0.055, 7, 22), mats.danger);
    warning.rotation.x = Math.PI / 2;
    warning.position.set(0, 0.12, 0);
    platform.group.add(warning);
  }
  if ([5, 11, 17].includes(index)) addSpinner(platform, p.w - 0.3);
  if (index > 0 && !p.finish && !p.checkpoint && index % 2 === 0) {
    addCoin(p.x, p.y + 1.05, p.z);
  }
});

// A few non-colliding skyline towers in the middle section.
for (let i = 0; i < 13; i++) {
  const z = -51 - i * 4.5;
  const side = i % 2 ? -1 : 1;
  const height = 3 + (i % 4) * 1.5;
  const building = new THREE.Mesh(
    new THREE.BoxGeometry(1.5 + (i % 3) * 0.45, height, 1.7),
    makeStandard(i % 2 ? 0x39386f : 0x2b4268, 0.32, 0.3, 0x6557c5, 0.35)
  );
  building.position.set(side * (8 + (i % 3) * 1.5), height / 2 - 0.5, z);
  building.castShadow = true;
  scene.add(building);
  const windowStrip = new THREE.Mesh(new THREE.BoxGeometry(0.08, height * 0.7, 0.08), mats.mint);
  windowStrip.position.set(building.position.x - side * 0.78, building.position.y, z - 0.4);
  scene.add(windowStrip);
}

// Lava-colored crystal scenery in the last part of the route.
for (let i = 0; i < 16; i++) {
  const crystal = new THREE.Mesh(
    new THREE.ConeGeometry(0.65 + (i % 3) * 0.2, 2 + (i % 4) * 0.7, 5),
    makeStandard(0xff714c, 0.28, 0.18, 0x9c2c19, 0.7)
  );
  crystal.position.set((i % 2 ? -1 : 1) * (8 + (i % 4)), 0.3 + (i % 3) * 0.2, -88 - i * 2.1);
  crystal.rotation.z = (i % 2 ? -1 : 1) * 0.16;
  crystal.castShadow = true;
  scene.add(crystal);
}

// Scenic set dressing: stylized trees, carved pylons, lanterns and layered district signage.
function addSkyTree(x, y, z, scale = 1) {
  const tree = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.13 * scale, 0.2 * scale, 1.4 * scale, 8), makeStandard(0x76533c, 0.95));
  trunk.position.y = 0.7 * scale; tree.add(trunk);
  const leaves = [0x4ec9a9, 0x2d9d91, 0x78dfb9];
  for (let i = 0; i < 3; i++) {
    const crown = new THREE.Mesh(new THREE.IcosahedronGeometry((0.72 - i * 0.08) * scale, 1), makeStandard(leaves[i], 0.82));
    crown.position.set((i - 1) * 0.24 * scale, (1.4 + i * 0.26) * scale, (i % 2 ? 0.12 : -0.12) * scale);
    crown.scale.set(1, 0.82, 0.92); crown.castShadow = true; tree.add(crown);
  }
  tree.position.set(x, y, z); scene.add(tree);
}
function addLantern(x, y, z, color = 0x54e2c6) {
  const g = new THREE.Group();
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.08, 1.35, 8), makeStandard(0x24364c, 0.42, 0.55));
  post.position.y = 0.67; g.add(post);
  const lamp = new THREE.Mesh(new THREE.OctahedronGeometry(0.22, 1), new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 1.1, metalness: .2, roughness: .25 }));
  lamp.position.y = 1.42; g.add(lamp);
  const light = new THREE.PointLight(color, 0.8, 4); light.position.y = 1.4; g.add(light);
  g.position.set(x,y,z); scene.add(g);
}
addSkyTree(-4.45, 0.05, -2.6, 1.0);
addSkyTree(4.35, 0.05, -2.8, 0.82);
addLantern(-4.85, 0.05, 2.0, 0x55e5cb);
addLantern(4.9, 0.05, 2.0, 0xffd06d);
addLantern(2.8, 2.15, -49.5, 0xa99aff);
addLantern(-1.05, 3.98, -85.6, 0xff8c55);

// Layered glowing windows make the Neon District feel like a city, not a row of blocks.
for (let i = 0; i < 13; i++) {
  const z = -51 - i * 4.5;
  const side = i % 2 ? -1 : 1;
  const height = 3 + (i % 4) * 1.5;
  const width = 1.5 + (i % 3) * 0.45;
  const glowMat = new THREE.MeshStandardMaterial({ color: i % 2 ? 0x67e8de : 0xc7a7ff, emissive: i % 2 ? 0x2bbaa9 : 0x7056be, emissiveIntensity: 0.9, roughness: 0.28 });
  for (let row = 0; row < Math.max(2, Math.floor(height / 0.72)); row++) {
    for (let col = 0; col < 2; col++) {
      const windowMesh = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.24, 0.035), glowMat);
      windowMesh.position.set(side * (8 + (i % 3) * 1.5) + (col ? width * 0.23 : -width * 0.23), 0.2 + row * 0.54, z - 0.86);
      scene.add(windowMesh);
    }
  }
}

function makeZoneArtwork(title, subtitle, theme) {
  const canvas = document.createElement('canvas');
  canvas.width = 640; canvas.height = 360;
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createLinearGradient(0, 0, 640, 360);
  gradient.addColorStop(0, theme[0]); gradient.addColorStop(1, theme[1]);
  ctx.fillStyle = gradient; ctx.fillRect(0, 0, 640, 360);
  for (let i=0;i<24;i++) {
    ctx.fillStyle = `rgba(255,255,255,${0.025 + (i%3)*0.012})`;
    ctx.beginPath(); ctx.arc((i*97)%640, (i*53)%360, 12+(i%5)*8, 0, Math.PI*2); ctx.fill();
  }
  if (title.includes('SKY')) {
    ctx.fillStyle = 'rgba(220,250,255,.72)';
    for (let i=0;i<5;i++){ctx.beginPath();ctx.ellipse(90+i*115,95+(i%2)*26,62,16,0,0,Math.PI*2);ctx.fill();}
    ctx.fillStyle = '#274e65';
    ctx.beginPath();ctx.moveTo(0,270);ctx.lineTo(115,185);ctx.lineTo(205,250);ctx.lineTo(330,155);ctx.lineTo(470,250);ctx.lineTo(560,195);ctx.lineTo(640,250);ctx.lineTo(640,360);ctx.lineTo(0,360);ctx.fill();
    ctx.fillStyle = '#58c8ae';ctx.beginPath();ctx.ellipse(320,285,155,24,0,0,Math.PI*2);ctx.fill();
    ctx.fillStyle = '#c9f4e8';ctx.beginPath();ctx.ellipse(320,266,95,13,0,0,Math.PI*2);ctx.fill();
  } else if (title.includes('NEON')) {
    for(let i=0;i<13;i++){
      const h=70+(i%5)*42, x=i*54-10;
      ctx.fillStyle=i%2?'rgba(38,48,93,.95)':'rgba(35,58,83,.95)';ctx.fillRect(x,310-h,37,h);
      ctx.fillStyle=i%2?'#65e8df':'#b99cff';
      for(let r=0;r<Math.floor(h/23);r++){ctx.fillRect(x+8,320-h+r*23,6,10);ctx.fillRect(x+22,320-h+r*23,6,10);}
    }
    ctx.strokeStyle='rgba(102,242,230,.75)';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(0,305);ctx.lineTo(640,305);ctx.stroke();
  } else {
    ctx.fillStyle='rgba(53,27,36,.9)';ctx.beginPath();ctx.moveTo(0,310);ctx.lineTo(125,205);ctx.lineTo(210,240);ctx.lineTo(325,112);ctx.lineTo(460,250);ctx.lineTo(540,190);ctx.lineTo(640,260);ctx.lineTo(640,360);ctx.lineTo(0,360);ctx.fill();
    ctx.fillStyle='#ff8e4a';ctx.shadowColor='#ff653a';ctx.shadowBlur=28;ctx.beginPath();ctx.ellipse(326,277,120,20,0,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
    for(let i=0;i<9;i++){ctx.fillStyle='rgba(255,171,87,.8)';ctx.fillRect(60+i*67,120+(i%3)*32,3,16);}
  }
  ctx.fillStyle='rgba(5,13,27,.72)';ctx.fillRect(0,0,640,86);
  ctx.font='900 39px Arial';ctx.fillStyle='#f5fbff';ctx.fillText(title,30,53);
  ctx.font='700 15px Arial';ctx.fillStyle=theme[2] || '#a6f8e7';ctx.fillText(subtitle,32,76);
  ctx.fillStyle='rgba(255,255,255,.65)';ctx.font='800 12px Arial';ctx.fillText('GIZABIT WORLDS',500,340);
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
  texture.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8);
  return texture;
}
function addWorldArtwork(x, y, z, title, subtitle, theme, rotation = 0) {
  const group=new THREE.Group();
  const frame=new THREE.Mesh(new THREE.BoxGeometry(3.85,2.28,.16),makeStandard(0x142a42,.34,.45,0x173f59,.35));
  const art=new THREE.Mesh(new THREE.PlaneGeometry(3.62,2.04),new THREE.MeshStandardMaterial({map:makeZoneArtwork(title,subtitle,theme),emissive:0xffffff,emissiveIntensity:.12,roughness:.65}));
  art.position.z=.09;group.add(frame);group.add(art);
  const bar=new THREE.Mesh(new THREE.BoxGeometry(3.9,.055,.22),new THREE.MeshStandardMaterial({color:theme[2] || 0x70e4d5,emissive:theme[2] || 0x70e4d5,emissiveIntensity:.7}));
  bar.position.y=-1.16;group.add(bar);
  group.position.set(x,y,z);group.rotation.y=rotation;scene.add(group);
}
addWorldArtwork(-8.2,3.1,-23.8,'SKY ISLANDS','FLOAT ABOVE THE CLOUDS',['#6eb9dd','#264a70','#bbfff0'],-0.15);
addWorldArtwork(8.9,4.7,-65.5,'NEON DISTRICT','CHASE THE CITY LIGHTS',['#4a4c9b','#111b3d','#8df3eb'],-0.18);
addWorldArtwork(-8.5,6.1,-100.2,'EMBER RUN','ONE LAST HEAT CHECK',['#b34f43','#351b2a','#ffc17a'],0.12);

function makeNameSprite(name) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(7,20,36,0.78)';
  roundRect(ctx, 8, 15, 496, 98, 26);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = 4;
  roundRect(ctx, 8, 15, 496, 98, 26);
  ctx.stroke();
  ctx.font = '800 48px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#f5ffff';
  ctx.fillText(String(name).slice(0, 16), 256, 65, 450);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: true }));
  sprite.scale.set(2.45, 0.62, 1);
  sprite.position.y = 2.85;
  return sprite;
}

function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + width, y, x + width, y + height, radius);
  ctx.arcTo(x + width, y + height, x, y + height, radius);
  ctx.arcTo(x, y + height, x, y, radius);
  ctx.arcTo(x, y, x + width, y, radius);
  ctx.closePath();
}

function createAvatar(color = '#51dfc7', name = '', addLabel = false) {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.5, metalness: 0.04 });
  const darkMat = makeStandard(0x17263d, 0.65, 0.05);
  const faceMat = makeStandard(0xf1c7a4, 0.72, 0);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.31, 0.57, 4, 9), bodyMat);
  torso.position.y = 1.12;
  torso.castShadow = true;
  group.add(torso);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.245, 16, 12), faceMat);
  head.position.y = 1.82;
  head.castShadow = true;
  group.add(head);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.252, 14, 9, 0, Math.PI * 2, 0, Math.PI * 0.46), darkMat);
  hair.position.y = 1.89;
  group.add(hair);

  for (const eyeX of [-0.085, 0.085]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.027, 8, 6), darkMat);
    eye.position.set(eyeX, 1.83, -0.221);
    group.add(eye);
  }

  const armPivots = [];
  for (const side of [-1, 1]) {
    const armPivot = new THREE.Group();
    armPivot.position.set(side * 0.37, 1.38, 0);
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.095, 0.38, 3, 7), bodyMat);
    arm.position.y = -0.28;
    arm.castShadow = true;
    armPivot.add(arm);
    group.add(armPivot);
    armPivots.push(armPivot);
  }

  const legPivots = [];
  for (const side of [-1, 1]) {
    const legPivot = new THREE.Group();
    legPivot.position.set(side * 0.17, 0.78, 0);
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.105, 0.35, 3, 7), darkMat);
    leg.position.y = -0.28;
    leg.castShadow = true;
    legPivot.add(leg);
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.12, 0.34), makeStandard(0xe8f5fa, 0.42));
    shoe.position.set(0, -0.56, -0.075);
    legPivot.add(shoe);
    group.add(legPivot);
    legPivots.push(legPivot);
  }

  const pack = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.48, 0.19), darkMat);
  pack.position.set(0, 1.15, 0.29);
  group.add(pack);

  if (addLabel && name) group.add(makeNameSprite(name));
  group.userData = { armPivots, legPivots, torso };
  group.traverse((obj) => { if (obj.isMesh) { obj.castShadow = true; obj.receiveShadow = true; } });
  return group;
}

const launchParams = new URLSearchParams(window.location.search);
playerName = (launchParams.get('name') || 'Runner').replace(/[<>\u0000-\u001F]/g, '').trim().slice(0, 16) || 'Runner';
roomName = (launchParams.get('room') || 'GIZABIT').toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 10) || 'GIZABIT';
$('player-name').value = playerName;
$('room-code').value = roomName;

const colorOptions = ['#51dfc7', '#ffca70', '#ff6f91', '#8fa7ff', '#d49bff', '#a4e66d'];
const localColor = colorOptions[Math.floor(Math.random() * colorOptions.length)];
player.avatar = createAvatar(localColor, playerName, false);
scene.add(player.avatar);

function addRemote(data) {
  if (!data || !data.id || data.id === myId) return;
  const existing = remotePlayers.get(data.id);
  if (existing) {
    existing.target.set(data.x || 0, data.y || 0, data.z || 0);
    return;
  }
  const avatar = createAvatar(data.color || '#ffca70', data.name || 'Runner', true);
  avatar.position.set(data.x || 0, data.y || 0, data.z || 0);
  scene.add(avatar);
  remotePlayers.set(data.id, {
    avatar,
    target: new THREE.Vector3(data.x || 0, data.y || 0, data.z || 0),
    facing: Number(data.ry) || 0,
    moving: Boolean(data.moving),
    phase: Math.random() * 5
  });
  updatePlayerCount();
}

function removeRemote(id) {
  const remote = remotePlayers.get(id);
  if (!remote) return;
  scene.remove(remote.avatar);
  remote.avatar.traverse((obj) => {
    if (obj.geometry) obj.geometry.dispose();
    if (obj.material) {
      if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
      else obj.material.dispose();
    }
  });
  remotePlayers.delete(id);
  updatePlayerCount();
}

function updatePlayerCount(count) {
  $('player-count').textContent = Number.isFinite(count) ? count : remotePlayers.size + 1;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>\"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#39;' }[char]));
}

function showToast(message) {
  toastEl.textContent = message;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 1900);
}

function formatTime(seconds) {
  const total = Math.max(0, Math.floor(seconds));
  const minutes = String(Math.floor(total / 60)).padStart(2, '0');
  const secs = String(total % 60).padStart(2, '0');
  return `${minutes}:${secs}`;
}

function formatRaceTime(milliseconds) {
  const total = Math.max(0, Math.floor(Number(milliseconds) || 0));
  const minutes = String(Math.floor(total / 60000)).padStart(2, '0');
  const seconds = String(Math.floor((total % 60000) / 1000)).padStart(2, '0');
  const centiseconds = String(Math.floor((total % 1000) / 10)).padStart(2, '0');
  return `${minutes}:${seconds}.${centiseconds}`;
}

function sendGameMessage(type, payload = {}) {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type, ...payload }));
    return true;
  }
  return false;
}

function updateRoomLobby() {
  const panel = $('room-lobby');
  panel.classList.toggle('hidden', !hasJoinedRoom);
  $('room-status-label').textContent = roomStatus === 'running' ? 'RACE IN PROGRESS' : roomStatus === 'complete' ? 'RACE COMPLETE' : 'WAITING ROOM';
  const playersEl = $('room-players');
  playersEl.innerHTML = roomPlayers.map((p) => {
    const host = p.id === roomHostId;
    const finished = p.finished ? 'FINISHED' : 'READY';
    return `<div class="room-player"><span class="room-player-name">${escapeHtml(p.name)}${p.id === myId ? ' (YOU)' : ''}</span><small>${host ? 'HOST' : finished}</small></div>`;
  }).join('') || '<div class="room-player">Waiting for players…</div>';
  $('player-count').textContent = String(Math.max(1, roomPlayers.length));
  const startButton = $('start-race-button');
  const canStart = hasJoinedRoom && isRoomHost && roomStatus === 'waiting' && roomPlayers.length > 0;
  startButton.classList.toggle('hidden', !canStart);
  startButton.disabled = false;
  $('room-wait-note').textContent = roomStatus === 'running'
    ? 'The race is live. Late joins are closed until the next round.'
    : roomStatus === 'complete'
      ? (isRoomHost ? 'Everyone is done. Start another round when ready.' : 'Race complete. Waiting for the host to start another round.')
      : (isRoomHost ? 'You are the room host. Start when your friends have joined.' : 'You are in. Wait for the room host to start the race.');
}

function renderRaceResults(results = raceResults) {
  raceResults = Array.isArray(results) ? results : [];
  const list = $('race-results');
  if (!raceResults.length) {
    list.innerHTML = '<li>Waiting for finishers…</li>';
    return;
  }
  list.innerHTML = raceResults.map((r, i) => {
    const time = formatRaceTime(r.timeMs);
    return `<li><span>${i + 1}. ${escapeHtml(r.name || 'Runner')}${r.id === myId ? ' (YOU)' : ''}</span><span class="result-time">${time}</span></li>`;
  }).join('');
}

function syncRoomState(data) {
  if (!data || !Array.isArray(data.players)) return;
  roomStatus = data.status || roomStatus;
  roomHostId = data.hostId || roomHostId;
  isRoomHost = roomHostId === myId;
  roomPlayers = data.players;
  const ids = new Set(roomPlayers.map((p) => p.id));
  for (const id of [...remotePlayers.keys()]) if (!ids.has(id)) removeRemote(id);
  roomPlayers.forEach((p) => {
    if (p.id !== myId) {
      addRemote(p);
      const remote = remotePlayers.get(p.id);
      if (remote) {
        remote.target.set(p.x || 0, p.y || 0, p.z || 0);
        remote.facing = Number(p.ry) || 0;
        remote.moving = Boolean(p.moving);
      }
    }
  });
  updatePlayerCount(roomPlayers.length);
  updateRoomLobby();
  if (data.results) renderRaceResults(data.results);
}

function resetRaceLocally() {
  clearTimeout(startTimer);
  raceStartAt = 0;
  raceStartPerf = 0;
  gameStarted = false;
  paused = false;
  won = false;
  settingsOpen = false;
  localCoinCount = 0;
  startedAt = 0;
  elapsed = 0;
  currentStage = 1;
  player.pos.set(0, 0, 1.8);
  player.checkpoint.set(0, 0, 1.8);
  player.vel.set(0, 0, 0);
  player.facing = 0;
  player.moving = false;
  player.onGround = false;
  player.standingPlatform = null;
  player.avatar.position.copy(player.pos);
  for (const coin of coins) {
    coin.collected = false;
    coin.group.visible = true;
  }
  for (const platform of platforms) {
    if (platform.crumble) {
      platform.active = true;
      platform.group.visible = true;
      platform.crumbleStarted = null;
    }
    if (platform.moving) platform.group.position.x = platform.baseX;
  }
  $('coin-value').textContent = '0';
  $('time-value').textContent = '00:00';
  $('progress-fill').style.width = '0%';
  $('progress-value').textContent = '0%';
  $('stage-value').textContent = 'WORLD 01 · SKY ISLANDS';
  $('final-time').textContent = '00:00';
  $('final-coins').textContent = '0';
  scene.background.setHex(0x91ccef);
  scene.fog.color.setHex(0x91ccef);
  winScreen.classList.add('hidden');
  pauseScreen.classList.add('hidden');
  settingsScreen.classList.add('hidden');
  topHud.classList.add('hidden');
  bottomHud.classList.add('hidden');
  menuScreen.classList.remove('hidden');
  updateMobileControlVisibility();
  renderRaceResults([]);
  Object.keys(keyState).forEach((key) => { keyState[key] = false; });
  resetJoystick();
  cameraYaw = 0;
  cameraPitch = 0.34;
  cameraDistance = 8;
  if (document.pointerLockElement) document.exitPointerLock();
  showToast('Back in the room — ready for another race');
}

function handleGameMessage(data) {
  if (!data || typeof data !== 'object') return;
  if (data.type === 'GAME_JOINED') {
    if (!data.ok) {
      pendingJoin = false;
      $('connection-message').textContent = data.message || 'Could not join this room.';
      $('play-button').disabled = false;
      $('play-button').style.opacity = '1';
      return;
    }
    pendingJoin = false;
    hasJoinedRoom = true;
    myId = data.id;
    roomName = data.room || roomName;
    roomStatus = data.status || 'waiting';
    isRoomHost = !!data.isHost;
    roomHostId = data.hostId || (data.isHost ? data.id : null);
    $('room-value').textContent = roomName;
    $('room-code').value = roomName;
    $('play-button').disabled = true;
    $('play-button').style.opacity = '0.55';
    $('play-button').innerHTML = '<span>JOINED THE ROOM</span><b>✓</b>';
    $('connection-message').textContent = `Room ${roomName} connected. Share this code with your friends.`;
    syncRoomState(data);
    updateRoomLobby();
    showToast(isRoomHost ? 'Room created — invite your friends!' : 'Joined the Parkour room!');
    return;
  }
  if (data.type === 'GAME_ERROR') {
    $('connection-message').textContent = data.message || 'Room error.';
    return;
  }
  if (data.type === 'GAME_ROOM_STATE') {
    syncRoomState(data);
    return;
  }
  if (data.type === 'PLAYER_MOVED') {
    const p = data.player;
    if (!p || p.id === myId) return;
    if (!remotePlayers.has(p.id)) addRemote(p);
    const remote = remotePlayers.get(p.id);
    if (remote) {
      remote.target.set(p.x || 0, p.y || 0, p.z || 0);
      remote.facing = Number(p.ry) || 0;
      remote.moving = Boolean(p.moving);
    }
    return;
  }
  if (data.type === 'RACE_START') {
    roomStatus = 'running';
    raceStartAt = Number(data.startAt) || Date.now();
    raceStartPerf = performance.now() + 3500;
    updateRoomLobby();
    const begin = () => {
      const remaining = raceStartPerf - performance.now();
      if (remaining > 30) {
        startTimer = setTimeout(begin, Math.min(remaining, 100));
        return;
      }
      enterGame(raceStartPerf);
    };
    const tick = () => {
      const left = Math.max(0, Math.ceil((raceStartPerf - performance.now()) / 1000));
      if (left > 0) {
        showToast(`RACE STARTS IN ${left}…`);
        startTimer = setTimeout(tick, 250);
      } else begin();
    };
    tick();
    return;
  }
  if (data.type === 'RACE_FINISH_UPDATE' || data.type === 'RACE_COMPLETE') {
    renderRaceResults(data.results || []);
    if (data.status) roomStatus = data.status;
    if (won) $('replay-button').textContent = isRoomHost ? 'RACE AGAIN' : 'WAIT FOR HOST';
    if (data.type === 'RACE_COMPLETE') showToast('Race complete — check the leaderboard!');
    updateRoomLobby();
    return;
  }
  if (data.type === 'RACE_RESET') {
    roomStatus = 'waiting';
    syncRoomState(data);
    resetRaceLocally();
    updateRoomLobby();
  }
}

function startNetwork() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  socket = new WebSocket(`${protocol}//${window.location.host}/?channel=parkour`);
  socket.addEventListener('open', () => {
    socket.send(JSON.stringify({ type: 'GAME_JOIN', name: playerName, room: roomName, color: localColor }));
  }, { once: true });
  socket.addEventListener('message', (event) => {
    try { handleGameMessage(JSON.parse(event.data)); } catch (_) { /* Ignore malformed packets. */ }
  });
  socket.addEventListener('error', () => {
    if (!hasJoinedRoom) {
      pendingJoin = false;
      $('connection-message').textContent = 'Cannot reach GizaBit. Start the GizaBit server first.';
      $('play-button').disabled = false;
      $('play-button').style.opacity = '1';
    }
  });
  socket.addEventListener('close', () => {
    roomStatus = 'disconnected';
    hasJoinedRoom = false;
    isRoomHost = false;
    roomHostId = null;
    roomPlayers = [];
    pendingJoin = false;
    socket = null;
    $('play-button').disabled = false;
    $('play-button').style.opacity = '1';
    $('play-button').innerHTML = '<span>RECONNECT TO ROOM</span><b>↗</b>';
    $('connection-message').textContent = 'Connection closed. Return to the room to reconnect.';
    updateRoomLobby();
    if (gameStarted && !won) showToast('Connection lost — finish offline or return to GizaBit.');
  });
}

function enterGame(startAtPerformance = performance.now()) {
  gameStarted = true;
  paused = false;
  won = false;
  startedAt = startAtPerformance;
  menuScreen.classList.add('hidden');
  pauseScreen.classList.add('hidden');
  winScreen.classList.add('hidden');
  topHud.classList.remove('hidden');
  bottomHud.classList.remove('hidden');
  $('connection-message').textContent = 'Race is live! Reach the finish first.';
  updatePlayerCount(roomPlayers.length);
  showToast(isTouchDevice ? 'Drag to look · Pinch to zoom' : 'Reach the glowing finish gate!');
  renderer.domElement.focus();
  updateMobileControlVisibility();
  if (!isTouchDevice) renderer.domElement.requestPointerLock?.();
}

$('play-button').addEventListener('click', () => {
  if (pendingJoin || hasJoinedRoom) return;
  playerName = ($('player-name').value.trim() || 'Runner').slice(0, 16);
  roomName = ($('room-code').value.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 10) || 'GIZABIT');
  $('player-name').value = playerName;
  $('room-code').value = roomName;
  $('connection-message').textContent = 'Connecting to the GizaBit room…';
  $('play-button').disabled = true;
  $('play-button').style.opacity = '0.6';
  pendingJoin = true;
  if (socket && socket.readyState === WebSocket.OPEN) {
    sendGameMessage('GAME_JOIN', { name: playerName, room: roomName, color: localColor });
  } else if (socket && socket.readyState === WebSocket.CONNECTING) {
    pendingJoin = false;
    $('connection-message').textContent = 'Still connecting… please try again in a moment.';
    $('play-button').disabled = false;
    $('play-button').style.opacity = '1';
  } else {
    startNetwork();
  }
});

$('start-race-button').addEventListener('click', () => {
  if (!isRoomHost || roomStatus !== 'waiting') return;
  $('start-race-button').disabled = true;
  $('room-wait-note').textContent = 'Starting the race…';
  if (!sendGameMessage('RACE_START')) {
    $('start-race-button').disabled = false;
    showToast('Connection lost. Reconnect to start.');
  }
});

const mobileControls = $('mobile-controls');
const isTouchDevice = window.matchMedia('(pointer: coarse)').matches || ('ontouchstart' in window);
const arrowsControl = $('mobile-arrows');
const joystickControl = $('mobile-joystick');

try {
  controlMode = localStorage.getItem('parkourRushControlMode') || 'arrows';
  cameraSensitivity = Number(localStorage.getItem('parkourRushCameraSensitivity')) || 1;
} catch (_) { /* Storage can be disabled in private browsing. */ }
$('camera-sensitivity').value = String(Math.round(cameraSensitivity * 100));
$('sensitivity-value').textContent = `${Math.round(cameraSensitivity * 100)}%`;

function applyControlMode(mode) {
  controlMode = mode === 'joystick' ? 'joystick' : 'arrows';
  arrowsControl.classList.toggle('hidden', controlMode !== 'arrows');
  joystickControl.classList.toggle('hidden', controlMode !== 'joystick');
  document.querySelectorAll('[data-control]').forEach((button) => {
    button.classList.toggle('selected', button.dataset.control === controlMode);
  });
  try { localStorage.setItem('parkourRushControlMode', controlMode); } catch (_) {}
}
function updateMobileControlVisibility() {
  mobileControls.classList.toggle('hidden', !(isTouchDevice && gameStarted && !paused && !won && !settingsOpen));
}
function openSettings() {
  Object.keys(keyState).forEach((key) => { keyState[key] = false; });
  resetJoystick();
  cameraPointers.clear(); previousPinchDistance = null; previousSinglePointer = null;
  settingsOpen = true;
  settingsScreen.classList.remove('hidden');
  if (document.pointerLockElement) document.exitPointerLock();
  updateMobileControlVisibility();
}
function closeSettings() {
  settingsOpen = false;
  settingsScreen.classList.add('hidden');
  updateMobileControlVisibility();
  if (gameStarted && !paused && !won && !isTouchDevice) renderer.domElement.requestPointerLock?.();
}
applyControlMode(controlMode);
$('open-settings-menu').addEventListener('click', openSettings);
$('settings-button').addEventListener('click', openSettings);
$('open-settings-pause').addEventListener('click', openSettings);
$('close-settings').addEventListener('click', closeSettings);
document.querySelectorAll('[data-control]').forEach((button) => {
  button.addEventListener('click', () => applyControlMode(button.dataset.control));
});
$('camera-sensitivity').addEventListener('input', (event) => {
  cameraSensitivity = Number(event.target.value) / 100;
  $('sensitivity-value').textContent = `${event.target.value}%`;
  try { localStorage.setItem('parkourRushCameraSensitivity', String(cameraSensitivity)); } catch (_) {}
});

$('resume-button').addEventListener('click', () => {
  paused = false;
  pauseScreen.classList.add('hidden');
  updateMobileControlVisibility();
  if (!isTouchDevice) renderer.domElement.requestPointerLock?.();
});
$('replay-button').addEventListener('click', () => {
  if (!isRoomHost) {
    showToast('The room host starts the next race.');
    return;
  }
  if (!sendGameMessage('RACE_RESET')) showToast('Connection lost. Reconnect to GizaBit.');
});

function pauseGame() {
  if (!gameStarted || won || settingsOpen) return;
  paused = !paused;
  pauseScreen.classList.toggle('hidden', !paused);
  if (paused && document.pointerLockElement) document.exitPointerLock();
  updateMobileControlVisibility();
  if (!paused && !isTouchDevice) renderer.domElement.requestPointerLock?.();
}

document.addEventListener('keydown', (e) => {
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.code === 'Escape' && settingsOpen) { closeSettings(); return; }
  if (settingsOpen) return;
  keyState[e.code] = true;
  if (e.code === 'Escape' && gameStarted && !won) pauseGame();
});
document.addEventListener('keyup', (e) => { keyState[e.code] = false; });
renderer.domElement.addEventListener('click', () => {
  if (!isTouchDevice && gameStarted && !paused && !settingsOpen && !won && document.pointerLockElement !== renderer.domElement) {
    renderer.domElement.requestPointerLock?.();
  }
});
document.addEventListener('pointerlockchange', () => {
  isPointerLocked = document.pointerLockElement === renderer.domElement;
});
document.addEventListener('mousemove', (e) => {
  if (!isPointerLocked || !gameStarted || paused || settingsOpen) return;
  cameraYaw -= e.movementX * 0.0025 * cameraSensitivity;
  cameraPitch = THREE.MathUtils.clamp(cameraPitch - e.movementY * 0.0018 * cameraSensitivity, 0.12, 1.28);
});

// On touch screens, any free area of the world becomes a two-finger orbit/zoom camera pad.
renderer.domElement.style.touchAction = 'none';
renderer.domElement.addEventListener('pointerdown', (e) => {
  if (e.pointerType !== 'touch' || !gameStarted || paused || settingsOpen || won) return;
  e.preventDefault();
  renderer.domElement.setPointerCapture?.(e.pointerId);
  cameraPointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (cameraPointers.size >= 2) {
    const pts = [...cameraPointers.values()];
    previousPinchDistance = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
    previousSinglePointer = null;
  } else {
    previousSinglePointer = { x: e.clientX, y: e.clientY };
    previousPinchDistance = null;
  }
}, { passive: false });
renderer.domElement.addEventListener('pointermove', (e) => {
  if (e.pointerType !== 'touch' || !cameraPointers.has(e.pointerId) || paused || settingsOpen) return;
  e.preventDefault();
  cameraPointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (cameraPointers.size >= 2) {
    const pts = [...cameraPointers.values()];
    const distance = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
    if (previousPinchDistance !== null) {
      cameraDistance = THREE.MathUtils.clamp(cameraDistance - (distance - previousPinchDistance) * 0.025, 4.2, 15.5);
    }
    previousPinchDistance = distance;
  } else {
    const point = cameraPointers.get(e.pointerId);
    if (previousSinglePointer) {
      const dx = point.x - previousSinglePointer.x;
      const dy = point.y - previousSinglePointer.y;
      cameraYaw -= dx * 0.006 * cameraSensitivity;
      cameraPitch = THREE.MathUtils.clamp(cameraPitch - dy * 0.0045 * cameraSensitivity, 0.12, 1.30);
    }
    previousSinglePointer = { x: point.x, y: point.y };
  }
}, { passive: false });
function endCameraPointer(e) {
  cameraPointers.delete(e.pointerId);
  if (cameraPointers.size >= 2) {
    const pts = [...cameraPointers.values()];
    previousPinchDistance = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
    previousSinglePointer = null;
  } else if (cameraPointers.size === 1) {
    const point = [...cameraPointers.values()][0];
    previousSinglePointer = { x: point.x, y: point.y };
    previousPinchDistance = null;
  } else {
    previousSinglePointer = null;
    previousPinchDistance = null;
  }
}
renderer.domElement.addEventListener('pointerup', endCameraPointer);
renderer.domElement.addEventListener('pointercancel', endCameraPointer);

// Arrow-button mode.
mobileControls.querySelectorAll('[data-key]').forEach((button) => {
  const code = button.dataset.key;
  const down = (e) => { e.preventDefault(); keyState[code] = true; };
  const up = (e) => { e.preventDefault(); keyState[code] = false; };
  button.addEventListener('pointerdown', down);
  button.addEventListener('pointerup', up);
  button.addEventListener('pointerleave', up);
  button.addEventListener('pointercancel', up);
  button.addEventListener('contextmenu', (e) => e.preventDefault());
});

// Virtual analog joystick mode.
const joystickBase = joystickControl.querySelector('.joystick-base');
const joystickKnob = $('joystick-knob');
function updateJoystick(e) {
  const rect = joystickBase.getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  let dx = e.clientX - centerX, dy = e.clientY - centerY;
  const max = rect.width * 0.31;
  const length = Math.hypot(dx, dy);
  if (length > max) { dx = dx / length * max; dy = dy / length * max; }
  joystickInput = { x: dx / max, y: dy / max };
  joystickKnob.style.setProperty('--knob-x', `${dx}px`);
  joystickKnob.style.setProperty('--knob-y', `${dy}px`);
}
function resetJoystick() {
  joystickInput = { x: 0, y: 0 };
  joystickPointerId = null;
  joystickKnob.style.setProperty('--knob-x', '0px');
  joystickKnob.style.setProperty('--knob-y', '0px');
}
joystickControl.addEventListener('pointerdown', (e) => {
  e.preventDefault(); joystickPointerId = e.pointerId;
  joystickControl.setPointerCapture?.(e.pointerId); updateJoystick(e);
});
joystickControl.addEventListener('pointermove', (e) => {
  if (e.pointerId === joystickPointerId) { e.preventDefault(); updateJoystick(e); }
});
joystickControl.addEventListener('pointerup', resetJoystick);
joystickControl.addEventListener('pointercancel', resetJoystick);

$('mobile-jump').addEventListener('pointerdown', (e) => { e.preventDefault(); keyState.Space = true; });
$('mobile-jump').addEventListener('pointerup', () => { keyState.Space = false; });
$('mobile-jump').addEventListener('pointerleave', () => { keyState.Space = false; });
$('mobile-jump').addEventListener('pointercancel', () => { keyState.Space = false; });

function respawn(reason = 'Back to checkpoint!') {
  player.pos.copy(player.checkpoint);
  player.vel.set(0, 0, 0);
  player.onGround = false;
  player.standingPlatform = null;
  showToast(reason);
}

function updatePlatforms(time, dt) {
  for (const platform of platforms) {
    const oldX = platform.group.position.x;
    const oldZ = platform.group.position.z;
    if (platform.moving) {
      platform.group.position.x = platform.baseX + Math.sin(time * platform.moveSpeed + platform.moveOffset) * platform.moveDistance;
    }
    platform.deltaX = platform.group.position.x - oldX;
    platform.deltaZ = platform.group.position.z - oldZ;
    if (player.onGround && player.standingPlatform === platform && platform.active) {
      player.pos.x += platform.deltaX;
      player.pos.z += platform.deltaZ;
    }
    if (platform.crumble && platform.crumbleStarted !== null) {
      const age = time - platform.crumbleStarted;
      if (age > 0.78 && platform.active) {
        platform.active = false;
        platform.group.visible = false;
        if (player.standingPlatform === platform) { player.onGround = false; player.standingPlatform = null; }
      }
      if (age > 4.2 && !platform.active) {
        platform.active = true;
        platform.group.visible = true;
        platform.crumbleStarted = null;
      }
    }
  }
  for (const hazard of hazards) {
    hazard.angle += hazard.speed * dt;
    hazard.group.rotation.y = hazard.angle;
  }
}

function updatePlayer(dt) {
  if (!gameStarted || paused || settingsOpen || won) return;

  const forwardInput = (keyState.KeyW || keyState.ArrowUp ? 1 : 0) - (keyState.KeyS || keyState.ArrowDown ? 1 : 0) - joystickInput.y;
  const sideInput = (keyState.KeyD || keyState.ArrowRight ? 1 : 0) - (keyState.KeyA || keyState.ArrowLeft ? 1 : 0) + joystickInput.x;
  const inputLength = Math.hypot(forwardInput, sideInput);
  const normalizer = inputLength > 1 ? 1 / inputLength : 1;
  const f = forwardInput * normalizer;
  const s = sideInput * normalizer;
  const forwardX = -Math.sin(cameraYaw);
  const forwardZ = -Math.cos(cameraYaw);
  const rightX = Math.cos(cameraYaw);
  const rightZ = -Math.sin(cameraYaw);
  const wishX = (forwardX * f + rightX * s);
  const wishZ = (forwardZ * f + rightZ * s);
  const sprint = keyState.ShiftLeft || keyState.ShiftRight;
  const speed = sprint ? 8.8 : 7.15;
  const response = player.onGround ? 16 : 5.2;
  const blend = 1 - Math.exp(-response * dt);
  player.vel.x += (wishX * speed - player.vel.x) * blend;
  player.vel.z += (wishZ * speed - player.vel.z) * blend;
  if (inputLength < 0.04 && player.onGround) {
    const drag = Math.exp(-13.5 * dt);
    player.vel.x *= drag;
    player.vel.z *= drag;
  }

  if (keyState.Space && player.onGround) {
    player.vel.y = 9.35;
    player.onGround = false;
    player.standingPlatform = null;
    keyState.Space = false;
  }

  const oldY = player.pos.y;
  player.vel.y -= 22 * dt;
  player.pos.x += player.vel.x * dt;
  player.pos.z += player.vel.z * dt;
  const nextY = player.pos.y + player.vel.y * dt;
  let landed = null;

  if (player.vel.y <= 0) {
    const footRadius = 0.29;
    for (const platform of platforms) {
      if (!platform.active || !platform.group.visible) continue;
      const px = platform.group.position.x;
      const pz = platform.group.position.z;
      const nearestX = THREE.MathUtils.clamp(player.pos.x, px - platform.width / 2, px + platform.width / 2);
      const nearestZ = THREE.MathUtils.clamp(player.pos.z, pz - platform.depth / 2, pz + platform.depth / 2);
      const dx = player.pos.x - nearestX;
      const dz = player.pos.z - nearestZ;
      const feetOverlap = dx * dx + dz * dz <= footRadius * footRadius;
      const crossedTop = oldY >= platform.top - 0.28 && nextY <= platform.top + 0.045;
      if (feetOverlap && crossedTop && (!landed || platform.top > landed.top)) landed = platform;
    }
  }

  if (landed) {
    player.pos.y = landed.top;
    player.vel.y = 0;
    player.onGround = true;
    player.standingPlatform = landed;
    if (landed.crumble && landed.crumbleStarted === null) {
      landed.crumbleStarted = elapsed;
      showToast('Move! This tile is breaking!');
    }
    if (landed.checkpoint && !landed.activated) {
      landed.activated = true;
      player.checkpoint.set(landed.group.position.x, landed.top, landed.group.position.z + 0.8);
      showToast('CHECKPOINT SAVED');
    }
  } else {
    player.pos.y = nextY;
    player.onGround = false;
    player.standingPlatform = null;
  }

  player.moving = Math.hypot(player.vel.x, player.vel.z) > 0.45;
  if (player.moving) player.facing = Math.atan2(player.vel.x, -player.vel.z);
  player.avatar.position.copy(player.pos);
  player.avatar.rotation.y = player.facing;
  player.phase += dt * (player.moving ? (sprint ? 13 : 9) : 2);
  animateAvatar(player.avatar, player.phase, player.moving ? 1 : 0.08);

  if (player.pos.y < -12) respawn();

  // Sweeper collision uses the actual oriented bar footprint and player body height.
  for (const hazard of hazards) {
    const dx = player.pos.x - hazard.group.position.x;
    const dz = player.pos.z - hazard.group.position.z;
    const c = Math.cos(-hazard.angle);
    const sA = Math.sin(-hazard.angle);
    const localX = dx * c - dz * sA;
    const localZ = dx * sA + dz * c;
    const barY = hazard.group.position.y;
    const bodyVerticalOverlap = barY > player.pos.y + 0.16 && barY < player.pos.y + 1.82;
    const withinBarLength = Math.abs(localX) <= hazard.length / 2 + 0.31;
    const withinBarThickness = Math.abs(localZ) <= 0.48;
    if (bodyVerticalOverlap && withinBarLength && withinBarThickness) {
      respawn('The sweeper hit you! Try again.');
      break;
    }
  }

  for (const coin of coins) {
    if (coin.collected) continue;
    coin.group.rotation.y += dt * 1.8;
    coin.group.position.y = coin.baseY + Math.sin(elapsed * 2.8 + coin.baseY) * 0.12;
    if (player.pos.distanceTo(coin.group.position) < 1.15) {
      coin.collected = true;
      coin.group.visible = false;
      localCoinCount += 1;
      $('coin-value').textContent = localCoinCount;
      showToast('+1 COIN');
    }
  }

  const finish = platforms.find((p) => p.finish);
  if (finish && Math.abs(player.pos.x - finish.group.position.x) < 3.4 && Math.abs(player.pos.z - finish.group.position.z) < 3.0 && player.pos.y >= finish.top - 0.3) {
    finishRun();
  }

  const progress = THREE.MathUtils.clamp((-player.pos.z / 111) * 100, 0, 100);
  $('progress-fill').style.width = `${progress}%`;
  $('progress-value').textContent = `${Math.round(progress)}%`;
  const stage = player.pos.z > -51 ? 1 : player.pos.z > -87 ? 2 : 3;
  if (stage !== currentStage) {
    currentStage = stage;
    const names = ['WORLD 01 · SKY ISLANDS', 'WORLD 02 · NEON DISTRICT', 'WORLD 03 · EMBER RUN'];
    $('stage-value').textContent = names[stage - 1];
    showToast(names[stage - 1]);
    const colors = [0x91ccef, 0x7779b6, 0xd37e66];
    scene.background.setHex(colors[stage - 1]);
    scene.fog.color.setHex(colors[stage - 1]);
  }

  if (socket?.readyState === WebSocket.OPEN && gameStarted && performance.now() - lastNetworkSend > 50) {
    lastNetworkSend = performance.now();
    sendGameMessage('PLAYER_MOVE', {
      x: player.pos.x, y: player.pos.y, z: player.pos.z,
      ry: player.facing, moving: player.moving
    });
  }
}

function animateAvatar(avatar, phase, amount) {
  if (!avatar?.userData?.legPivots) return;
  const swing = Math.sin(phase) * 0.48 * amount;
  avatar.userData.legPivots[0].rotation.x = swing;
  avatar.userData.legPivots[1].rotation.x = -swing;
  avatar.userData.armPivots[0].rotation.x = -swing * 0.7;
  avatar.userData.armPivots[1].rotation.x = swing * 0.7;
}

function updateRemotes(dt) {
  for (const remote of remotePlayers.values()) {
    remote.avatar.position.lerp(remote.target, Math.min(1, dt * 12));
    remote.avatar.rotation.y = remote.facing;
    remote.phase += dt * (remote.moving ? 9 : 2);
    animateAvatar(remote.avatar, remote.phase, remote.moving ? 0.8 : 0.05);
  }
}

function updateCamera(dt) {
  const horizontal = cameraDistance * Math.cos(cameraPitch);
  const height = cameraDistance * Math.sin(cameraPitch) + 1.15;
  const desired = new THREE.Vector3(
    player.pos.x + Math.sin(cameraYaw) * horizontal,
    player.pos.y + height,
    player.pos.z + Math.cos(cameraYaw) * horizontal
  );
  camera.position.lerp(desired, 1 - Math.exp(-7.5 * dt));
  const target = new THREE.Vector3(player.pos.x, player.pos.y + 0.95, player.pos.z - 0.35);
  camera.lookAt(target);
}

function finishRun() {
  if (won) return;
  won = true;
  const finalSeconds = Math.max(0, (performance.now() - startedAt) / 1000);
  $('final-time').textContent = formatTime(finalSeconds);
  $('final-coins').textContent = String(localCoinCount);
  $('win-summary').textContent = 'Finish recorded. Keep an eye on your friends — the leaderboard updates live.';
  sendGameMessage('PLAYER_FINISH', { coins: localCoinCount });
  renderRaceResults(raceResults);
  winScreen.classList.remove('hidden');
  $('replay-button').textContent = isRoomHost ? 'RACE AGAIN' : 'WAIT FOR HOST';
  updateMobileControlVisibility();
  if (document.pointerLockElement) document.exitPointerLock();
}

function renderLoop(now) {
  requestAnimationFrame(renderLoop);
  const dt = Math.min(0.035, Math.max(0.001, (now - (renderLoop.last || now)) / 1000));
  renderLoop.last = now;
  elapsed = gameStarted ? (now - startedAt) / 1000 : now / 1000;
  updatePlatforms(elapsed, dt);
  if (gameStarted && !paused && !won) {
    updatePlayer(dt);
    updateCamera(dt);
    $('time-value').textContent = formatTime((now - startedAt) / 1000);
  }
  updateRemotes(dt);
  renderer.render(scene, camera);
}
requestAnimationFrame(renderLoop);

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobileRender ? 1.45 : 1.8));
});

// Keep the local runner on a safe start pad and make the first screen feel alive.
player.avatar.position.copy(player.pos);
$('stage-value').textContent = 'WORLD 01 · SKY ISLANDS';
updateMobileControlVisibility();
