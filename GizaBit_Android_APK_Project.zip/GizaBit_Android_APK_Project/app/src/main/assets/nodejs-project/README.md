# GizaBit Console v2.0

GizaBit runs as one local LAN server. Start it from this folder with `npm start` (or the existing Windows launcher, if included in your copy), then open `http://localhost:3000` on the host and use the shown LAN URL on friends’ devices connected to the same hotspot/router. No internet connection is required for the local game server.

## Parkour Rush Multiplayer

1. Every player connects to the same GizaBit host URL.
2. Open **Games → Parkour Rush** on each device. The console fills in the local profile name and the default room code `GIZABIT`.
3. Players must use the same room code. The first player is the room host; other players appear in the room list.
4. When everyone is ready, the host presses **START RACE**. All runners start after the same 3.5-second countdown.
5. Finish times are recorded by the GizaBit server and the leaderboard updates for everyone. The host can press **RACE AGAIN** after finishing to return everybody to the room for another round.

Parkour Rush uses the existing GizaBit WebSocket server and bundled local Three.js modules. It does not start a second server or require Socket.IO. Existing game folders and console screens are kept in place.

## Notes

- GizaBit lobby and Parkour rooms support up to 8 connected players.
- Keep the host device awake and its hotspot enabled during play.
- Windows firewall may ask permission for Node.js; allow it on Private networks so friends can connect.


## Android Offline Host
See `android/README_AR.md` for running the GizaBit server on an Android phone with Termux. The Android phone can host a Wi-Fi hotspot, display a QR join code, and serve all bundled games locally. Mobile browsers require each player to tap the Full Screen button once.

## Fully Offline Game Assets
External CDN/font/analytics/ad/score endpoints have been removed from the Ludo, Hextris, and Space Racing game startup paths. Ludo uses the local Three.js bundle already included with Parkour Rush.
