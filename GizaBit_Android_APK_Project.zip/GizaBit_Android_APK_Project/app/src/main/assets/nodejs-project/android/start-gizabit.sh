#!/data/data/com.termux/files/usr/bin/bash
# GizaBit Android Host launcher for Termux (offline after Node.js is installed).
set -e
cd "$(dirname "$0")/.."

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed in Termux yet."
  echo "One-time setup while internet is available: pkg update && pkg install nodejs-lts"
  exit 1
fi

if [ ! -d "node_modules/express" ] || [ ! -d "node_modules/ws" ] || [ ! -d "node_modules/qrcode" ]; then
  echo "GizaBit dependencies are missing. Use the complete ZIP that includes node_modules."
  exit 1
fi

# Prevent Android from suspending the host process when the screen dims (if Termux:API exists).
if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock >/dev/null 2>&1 || true
fi

clear || true
echo "=================================================="
echo "             GizaBit Android Host"
echo "=================================================="
echo "1) Turn ON your Android Wi-Fi Hotspot."
echo "2) Keep this phone awake and keep Termux running."
echo "3) Friends join your hotspot and scan the QR shown in GizaBit."
echo "4) All game files are served from this phone; internet is not used."
echo "--------------------------------------------------"
echo "Starting local server on port 3000..."
echo "Opening the local console on this phone when Termux supports it..."
echo "Press CTRL+C to stop GizaBit."
echo "=================================================="
node server.js &
SERVER_PID=$!
cleanup() {
  kill "$SERVER_PID" 2>/dev/null || true
  if command -v termux-wake-unlock >/dev/null 2>&1; then termux-wake-unlock >/dev/null 2>&1 || true; fi
}
trap cleanup EXIT INT TERM
sleep 1
if command -v termux-open-url >/dev/null 2>&1; then
  termux-open-url "http://127.0.0.1:3000" >/dev/null 2>&1 || true
else
  echo "Open http://127.0.0.1:3000 manually on THIS phone."
fi
wait "$SERVER_PID"
