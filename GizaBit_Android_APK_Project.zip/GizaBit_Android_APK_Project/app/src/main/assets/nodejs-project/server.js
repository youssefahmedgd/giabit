const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const os = require('os');
const path = require('path');
const QRCode = require('qrcode');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = Number(process.env.PORT || 3000);
const MAX_PLAYERS = 8;

app.get('/api/health', (req, res) => res.json({ ok: true, name: 'GizaBit', port: PORT }));

app.use(express.static(path.join(__dirname, 'public')));

// Games directory
app.use('/games', express.static(path.join(__dirname, 'games')));

function getLocalAddresses() {
  const interfaces = os.networkInterfaces();
  const found = [];
  for (const [interfaceName, entries] of Object.entries(interfaces)) {
    for (const iface of entries || []) {
      const family = typeof iface.family === 'string' ? iface.family : String(iface.family);
      if (family !== 'IPv4' || iface.internal) continue;
      const address = String(iface.address || '');
      if (!address || address.startsWith('169.254.') || address === '0.0.0.0') continue;
      found.push({ address, interfaceName });
    }
  }
  // Android hotspot interfaces commonly use 192.168.43.1; prefer private LAN
  // ranges and avoid accidentally advertising a loopback/mobile carrier address.
  const score = (item) => {
    const a = item.address;
    if (a.startsWith('192.168.43.')) return 0;
    if (a.startsWith('192.168.')) return 1;
    if (a.startsWith('10.')) return 2;
    const m = a.match(/^172\.(\d+)\./);
    if (m && Number(m[1]) >= 16 && Number(m[1]) <= 31) return 3;
    return 9;
  };
  return found.sort((a, b) => score(a) - score(b));
}

function getLocalIP() {
  const override = String(process.env.GIZABIT_HOST_IP || '').trim();
  if (override) return override;
  const addresses = getLocalAddresses();
  return addresses.length ? addresses[0].address : '127.0.0.1';
}

// API endpoint that generates a 100% scannable QR Code image on the server side
app.get('/api/host-info', async (req, res) => {
  const ip = getLocalIP();
  const url = `http://${ip}:${PORT}`;
  
  try {
    const qrImage = await QRCode.toDataURL(url, {
      errorCorrectionLevel: 'M',
      margin: 2,
      scale: 8,
      color: { dark: '#0b0c12', light: '#ffffff' }
    });

    res.json({
      ip: ip,
      addresses: getLocalAddresses().map((entry) => entry.address),
      port: PORT,
      url: url,
      qrDataUrl: qrImage,
      maxPlayers: MAX_PLAYERS,
      platform: process.platform
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate QR' });
  }
});

const players = new Map();


// Parkour Rush room state shares this same GizaBit WebSocket server and port.
const gameRooms = new Map();
const gameClients = new Map();
const GAME_MAX_PLAYERS = 8;

function safeText(value, maxLength, fallback) {
  const text = String(value || '').replace(/[<>]/g, '').replace(/[\u0000-\u001F]/g, '').trim().slice(0, maxLength);
  return text || fallback;
}

function safeRoom(value) {
  return String(value || 'GIZABIT').toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 10) || 'GIZABIT';
}

function publicGamePlayer(player) {
  return {
    id: player.id,
    name: player.name,
    color: player.color,
    x: player.x, y: player.y, z: player.z,
    ry: player.ry,
    moving: player.moving,
    finished: player.finished,
    timeMs: player.timeMs
  };
}

function getRoomSnapshot(room) {
  return {
    type: 'GAME_ROOM_STATE',
    room: room.name,
    status: room.status,
    hostId: room.hostId,
    count: room.players.size,
    maxPlayers: GAME_MAX_PLAYERS,
    players: [...room.players.values()].map(publicGamePlayer),
    results: room.results
  };
}

function sendGame(ws, packet) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(packet));
}

function broadcastGameRoom(room, packet) {
  const serialized = JSON.stringify(packet);
  for (const ws of room.players.keys()) {
    if (ws.readyState === WebSocket.OPEN) ws.send(serialized);
  }
}

function broadcastGameRoomState(room) {
  broadcastGameRoom(room, getRoomSnapshot(room));
}

function sortedRaceResults(room) {
  return [...room.players.values()]
    .filter((p) => p.finished)
    .sort((a, b) => a.timeMs - b.timeMs)
    .map((p) => ({ id: p.id, name: p.name, timeMs: p.timeMs, coins: p.coins }));
}

function leaveGameRoom(ws) {
  const context = gameClients.get(ws);
  if (!context) return;
  gameClients.delete(ws);
  const room = gameRooms.get(context.room);
  if (!room) return;
  room.players.delete(ws);
  if (!room.players.size) {
    gameRooms.delete(room.name);
    return;
  }
  if (room.hostId === context.id) {
    const nextHost = room.players.values().next().value;
    room.hostId = nextHost ? nextHost.id : null;
  }
  room.results = sortedRaceResults(room);
  if (room.status === 'running' && [...room.players.values()].every((p) => p.finished)) room.status = 'complete';
  broadcastGameRoomState(room);
}

function handleParkourConnection(ws) {
  ws.on('message', (raw) => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch (_) { return; }
    const context = gameClients.get(ws);

    if (data.type === 'GAME_JOIN') {
      const roomName = safeRoom(data.room);
      const name = safeText(data.name, 16, 'Runner');
      const existingRoom = gameRooms.get(roomName);
      if (existingRoom && existingRoom.status !== 'waiting') {
        sendGame(ws, { type: 'GAME_JOINED', ok: false, message: 'السباق بدأ بالفعل. انتظر الجولة التالية أو استخدم كود غرفة أخرى.' });
        return;
      }
      if (existingRoom && existingRoom.players.size >= GAME_MAX_PLAYERS) {
        sendGame(ws, { type: 'GAME_JOINED', ok: false, message: `الغرفة ممتلئة (الحد ${GAME_MAX_PLAYERS} لاعبين).` });
        return;
      }
      if (context) leaveGameRoom(ws);
      let room = gameRooms.get(roomName);
      if (!room) {
        room = { name: roomName, players: new Map(), hostId: null, status: 'waiting', startAt: 0, results: [] };
        gameRooms.set(roomName, room);
      }
      const id = 'R_' + Math.random().toString(36).slice(2, 9).toUpperCase();
      const color = /^#[0-9a-f]{6}$/i.test(String(data.color || '')) ? String(data.color) : '#51dfc7';
      const player = {
        id, name, color, x: 0, y: 0, z: 1.8, ry: 0, moving: false,
        finished: false, timeMs: null, coins: 0
      };
      room.players.set(ws, player);
      if (!room.hostId) room.hostId = id;
      gameClients.set(ws, { room: roomName, id });
      sendGame(ws, {
        type: 'GAME_JOINED', ok: true, id, room: roomName,
        isHost: room.hostId === id, status: room.status,
        hostId: room.hostId, players: [...room.players.values()].map(publicGamePlayer),
        results: room.results, maxPlayers: GAME_MAX_PLAYERS
      });
      broadcastGameRoomState(room);
      return;
    }

    if (!context) return;
    const room = gameRooms.get(context.room);
    if (!room) return;
    const player = [...room.players.entries()].find(([client]) => client === ws)?.[1];
    if (!player) return;

    if (data.type === 'PLAYER_MOVE') {
      if (room.status !== 'running' || player.finished || Date.now() < room.startAt) return;
      const numberOr = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
      player.x = Math.max(-100, Math.min(100, numberOr(data.x)));
      player.y = Math.max(-30, Math.min(100, numberOr(data.y)));
      player.z = Math.max(-250, Math.min(100, numberOr(data.z)));
      player.ry = Math.max(-100, Math.min(100, numberOr(data.ry)));
      player.moving = Boolean(data.moving);
      const packet = JSON.stringify({ type: 'PLAYER_MOVED', player: publicGamePlayer(player) });
      for (const client of room.players.keys()) {
        if (client !== ws && client.readyState === WebSocket.OPEN) client.send(packet);
      }
      return;
    }

    if (data.type === 'RACE_START') {
      if (player.id !== room.hostId || room.status !== 'waiting' || !room.players.size) return;
      room.status = 'running';
      room.startAt = Date.now() + 3500;
      room.results = [];
      for (const p of room.players.values()) {
        p.x = 0; p.y = 0; p.z = 1.8; p.ry = 0; p.moving = false;
        p.finished = false; p.timeMs = null; p.coins = 0;
      }
      broadcastGameRoom(room, { type: 'RACE_START', startAt: room.startAt, room: room.name });
      broadcastGameRoomState(room);
      return;
    }

    if (data.type === 'PLAYER_FINISH') {
      if (room.status !== 'running' || player.finished || Date.now() < room.startAt) return;
      player.finished = true;
      player.moving = false;
      player.timeMs = Math.max(0, Date.now() - room.startAt);
      player.coins = Math.max(0, Math.min(999, Math.floor(Number(data.coins) || 0)));
      room.results = sortedRaceResults(room);
      const allFinished = [...room.players.values()].every((p) => p.finished);
      if (allFinished) room.status = 'complete';
      broadcastGameRoom(room, {
        type: allFinished ? 'RACE_COMPLETE' : 'RACE_FINISH_UPDATE',
        status: room.status,
        finisher: { id: player.id, name: player.name, timeMs: player.timeMs, coins: player.coins },
        results: room.results
      });
      return;
    }

    if (data.type === 'RACE_RESET') {
      if (player.id !== room.hostId) return;
      room.status = 'waiting';
      room.startAt = 0;
      room.results = [];
      for (const p of room.players.values()) {
        p.x = 0; p.y = 0; p.z = 1.8; p.ry = 0; p.moving = false;
        p.finished = false; p.timeMs = null; p.coins = 0;
      }
      const snapshot = getRoomSnapshot(room);
      broadcastGameRoom(room, { ...snapshot, type: 'RACE_RESET' });
      return;
    }
  });

  ws.on('close', () => leaveGameRoom(ws));
  ws.on('error', () => leaveGameRoom(ws));
}

function broadcastLobbyState() {
  const playerList = Array.from(players.values()).map(p => ({
    id: p.id,
    name: p.name,
    isHost: p.isHost
  }));

  const payload = JSON.stringify({
    type: 'LOBBY_UPDATE',
    count: players.size,
    max: MAX_PLAYERS,
    players: playerList
  });

  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  });
}

wss.on('connection', (ws, req) => {
  let channel = '';
  try { channel = new URL(req.url, 'http://localhost').searchParams.get('channel') || ''; } catch (_) {}
  if (channel === 'parkour') {
    handleParkourConnection(ws);
    return;
  }

  if (players.size >= MAX_PLAYERS) {
    ws.send(JSON.stringify({ type: 'ERROR', message: 'Lobby is full (8/8 players).' }));
    ws.close();
    return;
  }

  const clientIP = req.socket.remoteAddress;
  const isHost = clientIP.includes('127.0.0.1') || clientIP.includes('::1') || players.size === 0;
  const playerId = 'P_' + Math.random().toString(36).substring(2, 7).toUpperCase();
  const defaultName = isHost ? 'Host (You)' : `Player ${players.size + 1}`;

  players.set(ws, { id: playerId, name: defaultName, isHost: isHost });

  ws.send(JSON.stringify({
    type: 'WELCOME',
    id: playerId,
    name: defaultName,
    isHost: isHost
  }));

  broadcastLobbyState();

  ws.on('message', (rawMessage) => {
    try {
      const data = JSON.parse(rawMessage);
      if (data.type === 'SET_NAME' && data.name) {
        const player = players.get(ws);
        if (player) {
          player.name = data.name.substring(0, 16);
          broadcastLobbyState();
        }
      }
    } catch (err) {}
  });

  ws.on('close', () => {
    players.delete(ws);
    broadcastLobbyState();
  });
});

server.listen(PORT, '0.0.0.0', () => {
  const localIP = getLocalIP();
  console.log('==================================================');
  console.log('🎮 GizaBit Console Server is LIVE!');
  console.log(`🏠 Host Dashboard : http://localhost:${PORT}`);
  console.log(`📡 Friends Join URL: http://${localIP}:${PORT}`);
  console.log('==================================================');
});