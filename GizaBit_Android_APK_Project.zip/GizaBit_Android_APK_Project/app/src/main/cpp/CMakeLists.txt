cmake_minimum_required(VERSION 3.22.1)
project(gizabit_node_bridge)

# Headers and libnode.so are placed here by scripts/prepare-node-mobile.ps1.
set(NODE_MOBILE_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/node-mobile")
set(NODE_MOBILE_LIB "${CMAKE_CURRENT_SOURCE_DIR}/../jniLibs/${ANDROID_ABI}/libnode.so")

if(NOT EXISTS "${NODE_MOBILE_LIB}")
    message(FATAL_ERROR "Missing ${NODE_MOBILE_LIB}. Run scripts/prepare-node-mobile.ps1 first.")
endif()
if(NOT EXISTS "${NODE_MOBILE_ROOT}/include/node/node.h")
    message(FATAL_ERROR "Missing Node.js Mobile headers. Run scripts/prepare-node-mobile.ps1 first.")
endif()

add_library(node SHARED IMPORTED)
set_target_properties(node PROPERTIES IMPORTED_LOCATION "${NODE_MOBILE_LIB}")

add_library(native-lib SHARED native-lib.cpp)
target_include_directories(native-lib PRIVATE "${NODE_MOBILE_ROOT}/include/node")

find_library(log-lib log)
target_link_libraries(native-lib node ${log-lib})
