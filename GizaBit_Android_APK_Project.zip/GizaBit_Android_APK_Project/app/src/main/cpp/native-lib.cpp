#include <jni.h>
#include <cstdlib>
#include <cstring>
#include "node.h"

// Starts the embedded Node.js runtime on the Java worker thread.
extern "C" JNIEXPORT jint JNICALL
Java_com_gizabit_console_MainActivity_startNodeWithArguments(
        JNIEnv *env,
        jobject /* thiz */,
        jobjectArray arguments) {
    if (arguments == nullptr) return static_cast<jint>(1);

    const jsize argument_count = env->GetArrayLength(arguments);
    if (argument_count <= 0) return static_cast<jint>(1);

    size_t buffer_size = 0;
    for (jsize i = 0; i < argument_count; ++i) {
        auto item = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        if (item == nullptr) continue;
        const char *value = env->GetStringUTFChars(item, nullptr);
        if (value != nullptr) {
            buffer_size += std::strlen(value) + 1;
            env->ReleaseStringUTFChars(item, value);
        }
        env->DeleteLocalRef(item);
    }

    char *args_buffer = static_cast<char *>(std::calloc(buffer_size + 1, sizeof(char)));
    char **argv = static_cast<char **>(std::calloc(argument_count, sizeof(char *)));
    if (args_buffer == nullptr || argv == nullptr) {
        std::free(args_buffer);
        std::free(argv);
        return static_cast<jint>(1);
    }

    char *cursor = args_buffer;
    for (jsize i = 0; i < argument_count; ++i) {
        auto item = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        const char *value = item == nullptr ? "" : env->GetStringUTFChars(item, nullptr);
        const size_t length = value == nullptr ? 0 : std::strlen(value);
        argv[i] = cursor;
        if (length > 0) std::memcpy(cursor, value, length);
        cursor[length] = '\0';
        cursor += length + 1;
        if (item != nullptr) {
            if (value != nullptr) env->ReleaseStringUTFChars(item, value);
            env->DeleteLocalRef(item);
        }
    }

    const int result = node::Start(static_cast<int>(argument_count), argv);
    std::free(argv);
    std::free(args_buffer);
    return static_cast<jint>(result);
}
