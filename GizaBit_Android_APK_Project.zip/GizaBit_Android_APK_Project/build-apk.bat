@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-apk.ps1"
if errorlevel 1 (
  echo.
  echo APK build failed. Read the error above and check README_AR.md.
  pause
  exit /b 1
)
echo.
echo APK is ready in this folder: GizaBit-Android-Offline.apk
pause
